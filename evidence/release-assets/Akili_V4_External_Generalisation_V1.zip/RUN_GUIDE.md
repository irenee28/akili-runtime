# Akili V4 Run Guide

## Goal
Test six new structural convention families with four arms: stateless, bounded ICL, template-only, and full Akili.

## Development procedure
1. Upload `Akili_V4_-_External_Structural_Generalisation_Colab.ipynb` to Colab.
2. Select a CUDA GPU. T4 is supported for Qwen3-4B in 4-bit; RunPod is preferred for the frozen run.
3. Leave `AKILI_V4_PHASE` unset. The notebook must print `development` and seeds `[1, 2, 3]`.
4. Run all cells. The mock preflight must pass before model loading.
5. Do not edit prompts, templates, scorers, budgets, families, seeds, or gates after the real run starts.
6. Return `FINAL_RECEIPT.json` and the printed summary.

## Held-out procedure
Only after development passes and the implementation is frozen, start a fresh runtime with `AKILI_V4_PHASE=heldout`. It must print seeds `[4, 5, 6]`. Run once.

## Frozen criteria
- Akili accuracy >= 90%
- within 5 percentage points of bounded ICL or better
- acquisition, interruption return and post-supersession >= 90%
- prompt reduction >= 70%
- cross-scope retrieval = 0
- obsolete retrieval = 0
- all integrity gates pass
