#!/usr/bin/env python3
"""Akili V4 external structural-generalisation benchmark.

Four arms: stateless, bounded ICL, immediate-template-only, and full Akili.
Six operation families are structurally distinct from the V3.1.1a clamp/wrap
families. Development and held-out seeds are phase locked.
"""
from __future__ import annotations

import argparse
import ast
import copy
import dataclasses
import hashlib
import json
import os
import random
import re
import statistics
import tempfile
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

from akili_v311a_core import AkiliCore, BoundedICL, Stateless, truncate_to_budget

PROTOCOL = "akili-v4-external-structural-generalisation-v1"
LOCKED_PHASE_SEEDS = {"development": [1, 2, 3], "heldout": [4, 5, 6]}
ARMS = ["stateless", "bounded_icl", "template_only", "akili"]
FAMILIES = [
    "validation_exception",
    "serialization_mapping",
    "structured_logging",
    "config_precedence",
    "batch_tail_policy",
    "artifact_naming",
]


def canonical_hash(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()


def token_count_approx(text: str) -> int:
    return max(0, (len(text or "") + 3) // 4)


def operation_shape(family: str) -> str:
    return {
        "validation_exception": "unary_range_validation",
        "serialization_mapping": "record_to_dict_mapping",
        "structured_logging": "event_to_structured_log",
        "config_precedence": "first_non_null_precedence",
        "batch_tail_policy": "list_chunking_tail_policy",
        "artifact_naming": "path_string_naming",
    }[family]


def render_template(family: str) -> str:
    templates = {
        "validation_exception": '''def validate_value(value):
    if value < <LOWER_BOUND> or value > <UPPER_BOUND>:
        raise <EXCEPTION_TYPE>(<MESSAGE>)
    return value''',
        "serialization_mapping": '''def serialize_record(record):
    return {
        <OUTPUT_KEY_1>: record[<INPUT_KEY_1>],
        <OUTPUT_KEY_2>: record[<INPUT_KEY_2>],
    }''',
        "structured_logging": '''def build_log(event, tenant):
    return {
        "level": <LEVEL>,
        "message": <PREFIX> + event,
        "context": {"tenant": tenant, "source": <SOURCE>},
    }''',
        "config_precedence": '''def resolve_config(cli, env, file_value, default):
    for value in (<SOURCE_1>, <SOURCE_2>, <SOURCE_3>, <SOURCE_4>):
        if value is not None:
            return value
    return None''',
        "batch_tail_policy": '''def make_batches(items):
    batches = [items[index:index + <BATCH_SIZE>] for index in range(0, len(items), <BATCH_SIZE>)]
    if <DROP_INCOMPLETE> and batches and len(batches[-1]) < <BATCH_SIZE>:
        batches.pop()
    return batches''',
        "artifact_naming": '''def artifact_path(root, project, name):
    return f"{root}/{project}/<PREFIX>_{name}.<EXTENSION>"''',
    }
    return templates[family]


def current_template_memory(family: str) -> str:
    return (
        "MEMORY TYPE: CURRENT_INSTRUCTION_TEMPLATE\n"
        "Source: deterministic renderer from the current maintainer-confirmed convention.\n"
        "Status: structural and value-free; replace placeholders using CURRENT BRIEF JSON only.\n"
        + render_template(family)
    )


def public_rule(issue: Dict[str, Any]) -> str:
    family, p = issue["family"], issue["params"]
    if family == "validation_exception":
        return f"validate inclusively within [{p['low']}, {p['high']}], otherwise raise {p['exception']} with message {p['message']!r}"
    if family == "serialization_mapping":
        return f"map input keys {p['in1']!r},{p['in2']!r} to output keys {p['out1']!r},{p['out2']!r}"
    if family == "structured_logging":
        return f"return level {p['level']!r}, prefix {p['prefix']!r}, source {p['source']!r}, and tenant context"
    if family == "config_precedence":
        return "choose the first non-None source in order " + " > ".join(p["order"])
    if family == "batch_tail_policy":
        return f"batch size {p['size']} and drop_incomplete={p['drop']}"
    if family == "artifact_naming":
        return f"path root/project/{p['prefix']}_name.{p['ext']}"
    raise KeyError(family)


def expected_code(issue: Dict[str, Any]) -> str:
    p = issue["params"]
    f = issue["family"]
    if f == "validation_exception":
        return (
            "def validate_value(value):\n"
            f"    if value < {p['low']!r} or value > {p['high']!r}:\n"
            f"        raise {p['exception']}({p['message']!r})\n"
            "    return value\n"
        )
    if f == "serialization_mapping":
        return (
            "def serialize_record(record):\n"
            "    return {\n"
            f"        {p['out1']!r}: record[{p['in1']!r}],\n"
            f"        {p['out2']!r}: record[{p['in2']!r}],\n"
            "    }\n"
        )
    if f == "structured_logging":
        return (
            "def build_log(event, tenant):\n"
            "    return {\n"
            f"        'level': {p['level']!r},\n"
            f"        'message': {p['prefix']!r} + event,\n"
            f"        'context': {{'tenant': tenant, 'source': {p['source']!r}}},\n"
            "    }\n"
        )
    if f == "config_precedence":
        return (
            "def resolve_config(cli, env, file_value, default):\n"
            f"    for value in ({', '.join(p['order'])}):\n"
            "        if value is not None:\n"
            "            return value\n"
            "    return None\n"
        )
    if f == "batch_tail_policy":
        return (
            "def make_batches(items):\n"
            f"    batches = [items[index:index + {p['size']}] for index in range(0, len(items), {p['size']})]\n"
            f"    if {p['drop']} and batches and len(batches[-1]) < {p['size']}:\n"
            "        batches.pop()\n"
            "    return batches\n"
        )
    if f == "artifact_naming":
        return (
            "def artifact_path(root, project, name):\n"
            f"    return f\"{{root}}/{{project}}/{p['prefix']}_{{name}}.{p['ext']}\"\n"
        )
    raise KeyError(f)


def family_params(family: str, version: int, seed: int) -> Dict[str, Any]:
    rng = random.Random(seed * 10_000 + FAMILIES.index(family) * 100 + version)
    if family == "validation_exception":
        low = rng.choice([-10, -5, 0, 1]) + version
        high = low + rng.choice([7, 10, 15])
        return {"low": low, "high": high, "exception": "ValueError" if version % 2 else "RuntimeError", "message": f"range-v{version}"}
    if family == "serialization_mapping":
        return {"in1": f"id_v{version}", "in2": f"kind_v{version}", "out1": f"identifier_v{version}", "out2": f"category_v{version}"}
    if family == "structured_logging":
        return {"level": ["INFO", "WARNING", "ERROR"][version % 3], "prefix": f"v{version}:", "source": f"service-{rng.randrange(10,99)}"}
    if family == "config_precedence":
        orders = [
            ["cli", "env", "file_value", "default"],
            ["env", "cli", "file_value", "default"],
            ["file_value", "env", "cli", "default"],
        ]
        return {"order": orders[(version - 1) % len(orders)]}
    if family == "batch_tail_policy":
        return {"size": 2 + ((version + seed) % 4), "drop": bool(version % 2)}
    if family == "artifact_naming":
        return {"prefix": ["build", "artifact", "release"][version % 3], "ext": ["json", "txt", "dat"][seed % 3]}
    raise KeyError(family)


def make_env(seed: int) -> Dict[str, Any]:
    scopes = ["atlas", "beacon", "cedar"]
    family_scope = {family: scopes[i // 2] for i, family in enumerate(FAMILIES)}
    stages: List[List[Tuple[str, int, bool, str]]] = []
    # Two teach issues per version meet the frozen evidence threshold of two.
    stages.append([(f, 1, True, "acquisition_1") for f in FAMILIES])
    stages.append([(f, 1, True, "acquisition_2") for f in reversed(FAMILIES)])
    stages.append([(f, 1, False, "return_after_interruption") for f in FAMILIES])
    stages.append([(f, 2, True, "supersession_1") for f in reversed(FAMILIES)])
    stages.append([(f, 2, True, "supersession_2") for f in FAMILIES])
    stages.append([(f, 2, False, "post_supersession_return") for f in reversed(FAMILIES)])
    rng = random.Random(seed)
    issues: List[Dict[str, Any]] = []
    issue_id = 0
    for stage_index, stage in enumerate(stages):
        stage = list(stage)
        rng.shuffle(stage)
        for family, version, teach, slice_name in stage:
            issue_id += 1
            params = family_params(family, version, seed)
            issue = {
                "id": issue_id,
                "seed": seed,
                "scope": family_scope[family],
                "family": family,
                "shape": operation_shape(family),
                "version": version,
                "teach": teach,
                "slice": slice_name,
                "params": params,
                "rule": public_rule({"family": family, "params": params}),
            }
            issue["expected_code"] = expected_code(issue)
            issue["brief_json"] = json.dumps({
                "scope": issue["scope"], "family": family, "version": version,
                "parameters": params,
            }, sort_keys=True)
            issues.append(issue)
    env = {"seed": seed, "issues": issues, "families": FAMILIES, "scopes": scopes}
    env["environment_hash"] = canonical_hash(env)
    return env


ALLOWED_CALLS = {"range", "len"}
FORBIDDEN_NODES = (ast.Import, ast.ImportFrom, ast.While, ast.With, ast.AsyncWith, ast.Lambda, ast.ClassDef, ast.Global, ast.Nonlocal, ast.Delete, ast.Yield, ast.YieldFrom, ast.Await)


def normalize_content(content: str) -> str:
    text = (content or "").strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines).strip()
    return text


def safe_ast(code: str, expected_name: str) -> Tuple[bool, str]:
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        return False, f"syntax:{exc}"
    if len(tree.body) != 1 or not isinstance(tree.body[0], ast.FunctionDef):
        return False, "must contain exactly one function"
    fn = tree.body[0]
    if fn.name != expected_name:
        return False, f"wrong function name {fn.name}"
    for node in ast.walk(tree):
        if isinstance(node, FORBIDDEN_NODES):
            return False, f"forbidden node {type(node).__name__}"
        if isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            return False, "dunder attribute forbidden"
        if isinstance(node, ast.Name) and node.id.startswith("__"):
            return False, "dunder name forbidden"
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                if node.func.id not in ALLOWED_CALLS and node.func.id not in {"ValueError", "RuntimeError"}:
                    return False, f"call {node.func.id} forbidden"
            elif isinstance(node.func, ast.Attribute):
                if node.func.attr not in {"pop"}:
                    return False, f"method {node.func.attr} forbidden"
            else:
                return False, "dynamic call forbidden"
    return True, "ok"


def score_code(issue: Dict[str, Any], content: str) -> Tuple[bool, str]:
    code = normalize_content(content)
    expected_name = {
        "validation_exception": "validate_value",
        "serialization_mapping": "serialize_record",
        "structured_logging": "build_log",
        "config_precedence": "resolve_config",
        "batch_tail_policy": "make_batches",
        "artifact_naming": "artifact_path",
    }[issue["family"]]
    ok, reason = safe_ast(code, expected_name)
    if not ok:
        return False, reason
    namespace: Dict[str, Any] = {"__builtins__": {"range": range, "len": len, "ValueError": ValueError, "RuntimeError": RuntimeError}}
    try:
        exec(compile(code, "<candidate>", "exec"), namespace, namespace)
        fn = namespace[expected_name]
        p = issue["params"]
        if issue["family"] == "validation_exception":
            midpoint = (p["low"] + p["high"]) / 2
            if fn(midpoint) != midpoint:
                return False, "in-range result"
            exc_cls = ValueError if p["exception"] == "ValueError" else RuntimeError
            for value in (p["low"] - 1, p["high"] + 1):
                try:
                    fn(value)
                    return False, "missing exception"
                except exc_cls as exc:
                    if str(exc) != p["message"]:
                        return False, "wrong message"
        elif issue["family"] == "serialization_mapping":
            record = {p["in1"]: 7, p["in2"]: "x", "noise": 9}
            if fn(record) != {p["out1"]: 7, p["out2"]: "x"}:
                return False, "mapping mismatch"
        elif issue["family"] == "structured_logging":
            if fn("started", "tenant-a") != {"level": p["level"], "message": p["prefix"] + "started", "context": {"tenant": "tenant-a", "source": p["source"]}}:
                return False, "log mismatch"
        elif issue["family"] == "config_precedence":
            values = {"cli": "CLI", "env": "ENV", "file_value": "FILE", "default": "DEF"}
            args = [values[x] for x in ["cli", "env", "file_value", "default"]]
            if fn(*args) != values[p["order"][0]]:
                return False, "precedence mismatch"
            values[p["order"][0]] = None
            args = [values[x] for x in ["cli", "env", "file_value", "default"]]
            if fn(*args) != values[p["order"][1]]:
                return False, "fallback precedence mismatch"
        elif issue["family"] == "batch_tail_policy":
            items = list(range(p["size"] * 2 + 1))
            expected = [items[:p["size"]], items[p["size"]:p["size"]*2]]
            if not p["drop"]:
                expected.append(items[p["size"]*2:])
            if fn(items) != expected:
                return False, "batch mismatch"
        elif issue["family"] == "artifact_naming":
            if fn("/tmp", "alpha", "model") != f"/tmp/alpha/{p['prefix']}_model.{p['ext']}":
                return False, "path mismatch"
    except Exception as exc:
        return False, f"runtime:{type(exc).__name__}:{exc}"
    return True, "pass"


class TemplateOnly:
    name = "template_only"
    instance_id = "template-only"
    def switch_entity(self, _name: str) -> None: pass
    def observe_episode(self, *_args: Any, **_kwargs: Any) -> None: pass
    def report(self) -> Dict[str, Any]:
        return {"profiles": 0, "stored_memory_tokens": 0, "cross_scope_retrievals": 0, "state_bounded": True, "audit_valid": True}


def derive_v4(_stats: Dict[str, Any], _profile: Dict[str, Any], features: Dict[str, Any]):
    if not features.get("teach"):
        return None
    return {
        "family": features["family"],
        "rule": features["rule"],
        "decision_label": f"v{features['version']}",
        "lifecycle_state": "VERIFIED",
        "evidence": {"count": features["evidence_count"], "version": features["version"]},
        "admit_threshold": 2,
        "schema_template": render_template(features["family"]),
        "template_metadata": {
            "source": "v4_deterministic_public_metadata_renderer",
            "shape_key": operation_shape(features["family"]),
            "value_free": True,
        },
    }


def prompt_for(issue: Dict[str, Any], memory: str) -> Tuple[str, str]:
    system = (
        "You are a repository implementation agent. Return one JSON object with key content. "
        "content must contain exactly one Python function and no tests or prose."
    )
    teach = ""
    if issue["teach"]:
        teach = "\nCURRENT MAINTAINER CONVENTION:\n" + issue["rule"] + "\n"
    user = (
        f"WORKSPACE: {issue['scope']}\nFAMILY: {issue['family']}\n"
        + teach
        + "CURRENT BRIEF JSON:\n" + issue["brief_json"] + "\n"
        + ("ADAPTATION MEMORY:\n" + memory + "\n" if memory else "")
        + "Implement the required function now."
    )
    return system, user


class MockModel:
    """Pipeline oracle. It intentionally needs a structural template."""
    def __init__(self):
        self.calls = 0
    def __call__(self, _system: str, user: str, _schema: str, issue: Dict[str, Any]) -> Dict[str, Any]:
        self.calls += 1
        has_template = "CURRENT_INSTRUCTION_TEMPLATE" in user or "SCHEMA_TEMPLATE" in user
        if has_template:
            return {"content": issue["expected_code"], "prompt_tokens": token_count_approx(user), "generated_tokens": token_count_approx(issue["expected_code"]), "strict_json": True, "usable": True, "attempts": 1}
        return {"content": "def placeholder(*args):\n    return None\n", "prompt_tokens": token_count_approx(user), "generated_tokens": 8, "strict_json": True, "usable": True, "attempts": 1}


class HFModel:
    def __init__(self, model_name: str):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
        self.torch = torch
        assert torch.cuda.is_available(), "CUDA GPU required for real mode"
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        quant = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=dtype)
        self.tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token_id = self.tokenizer.eos_token_id
        self.model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", quantization_config=quant, torch_dtype=dtype)
        self.model.eval()
    def count(self, text: str) -> int:
        return len(self.tokenizer.encode(text or "", add_special_tokens=False))
    def _parse(self, raw: str) -> Tuple[Optional[Dict[str, Any]], bool]:
        text = raw.strip()
        try:
            obj = json.loads(text)
            return (obj if isinstance(obj, dict) and isinstance(obj.get("content"), str) else None), True
        except Exception:
            pass
        decoder = json.JSONDecoder()
        for match in re.finditer(r"\{", text):
            try:
                obj, _ = decoder.raw_decode(text[match.start():])
                if isinstance(obj, dict) and isinstance(obj.get("content"), str):
                    return obj, False
            except Exception:
                continue
        # Safe recovery for a plain Python function.
        lines = text.splitlines()
        for end in range(len(lines), 0, -1):
            candidate = "\n".join(lines[:end]).strip()
            try:
                tree = ast.parse(candidate)
                if len(tree.body) == 1 and isinstance(tree.body[0], ast.FunctionDef):
                    return {"content": candidate}, False
            except Exception:
                pass
        return None, False
    def __call__(self, system: str, user: str, _schema: str, issue: Dict[str, Any]) -> Dict[str, Any]:
        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        prompt = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True, enable_thinking=False)
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        attempts = 0
        total_prompt = total_generated = 0
        raw_outputs = []
        for retry in range(2):
            attempts += 1
            total_prompt += int(inputs["input_ids"].shape[-1])
            with self.torch.inference_mode():
                output = self.model.generate(**inputs, max_new_tokens=420, do_sample=False, pad_token_id=self.tokenizer.pad_token_id)
            generated = output[0, inputs["input_ids"].shape[-1]:]
            total_generated += int(generated.shape[-1])
            raw = self.tokenizer.decode(generated, skip_special_tokens=True)
            raw_outputs.append(raw)
            obj, strict = self._parse(raw)
            if obj is not None:
                return {"content": obj["content"], "prompt_tokens": total_prompt, "generated_tokens": total_generated, "strict_json": strict, "usable": True, "attempts": attempts, "raw_outputs": raw_outputs}
            retry_user = user + "\nYour prior answer was invalid. Return only one JSON object: {\"content\": \"def ...\"}."
            messages[-1]["content"] = retry_user
            prompt = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True, enable_thinking=False)
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        return {"content": "", "prompt_tokens": total_prompt, "generated_tokens": total_generated, "strict_json": False, "usable": False, "attempts": attempts, "raw_outputs": raw_outputs}


def run_arm(env: Dict[str, Any], arm: str, model: Any, budget_icl: int, budget_akili: int) -> Dict[str, Any]:
    count_fn = getattr(model, "count", token_count_approx)
    if arm == "stateless": system_obj: Any = Stateless(count_fn)
    elif arm == "bounded_icl": system_obj = BoundedICL(budget_icl, count_fn)
    elif arm == "template_only": system_obj = TemplateOnly()
    elif arm == "akili":
        system_obj = AkiliCore(budget_akili, count_fn, derive_v4, min_evidence=2, max_profiles=8, max_versions=64, recent_window=10, max_stats_keys=96, max_retrieval_log=512)
    else: raise KeyError(arm)

    evidence_counts: Dict[Tuple[str, str, int], int] = defaultdict(int)
    traces = []
    old_versions: Dict[Tuple[str, str], int] = {}
    for issue in env["issues"]:
        if hasattr(system_obj, "switch_entity"):
            system_obj.switch_entity(issue["scope"])
        memory = ""
        provenance = "NO_MEMORY"
        details: Dict[str, Any] = {}
        if arm == "bounded_icl":
            memory = system_obj.memory_prompt()
            provenance = "RAW_HISTORY"
        elif arm == "template_only" and issue["teach"]:
            memory = current_template_memory(issue["family"])
            provenance = "CURRENT_INSTRUCTION_TEMPLATE"
        elif arm == "akili":
            if issue["teach"]:
                memory = current_template_memory(issue["family"])
                provenance = "CURRENT_INSTRUCTION_TEMPLATE"
                details = {"current_instruction_template_retrieved": True}
            else:
                memory, details = system_obj.retrieval_context(issue["family"], issue["shape"])
                provenance = details.get("primary_memory_class", "NO_MEMORY")
        memory, memory_tokens = truncate_to_budget(memory, budget_akili if arm in {"akili", "template_only"} else budget_icl, count_fn)
        sys_prompt, user_prompt = prompt_for(issue, memory)
        response = model(sys_prompt, user_prompt, "content", issue)
        passed, reason = score_code(issue, response.get("content", ""))
        if arm == "bounded_icl":
            system_obj.observe_episode(
                summary=(
                    user_prompt + "\nASSISTANT OUTPUT:\n" + response.get("content", "")
                    + f"\nVERIFIER: {'PASS' if passed else 'FAIL'}"
                ),
                features={},
                entity_hint=issue["scope"], outcome="PASS" if passed else "FAIL",
            )
        elif arm == "akili":
            key = (issue["scope"], issue["family"], issue["version"])
            if issue["teach"]:
                evidence_counts[key] += 1
            system_obj.observe_episode(
                summary=f"{issue['family']} v{issue['version']}",
                features={
                    "teach": issue["teach"], "family": issue["family"], "version": issue["version"],
                    "rule": issue["rule"], "evidence_count": evidence_counts[key],
                    f"latest_{issue['family']}_version": issue["version"],
                },
                entity_hint=issue["scope"], outcome="PASS" if passed else "FAIL",
            )
        prior = old_versions.get((issue["scope"], issue["family"]))
        if issue["teach"] and evidence_counts.get((issue["scope"], issue["family"], issue["version"]), 0) >= 2:
            old_versions[(issue["scope"], issue["family"])] = issue["version"]
        trace = {
            "issue_id": issue["id"], "seed": issue["seed"], "arm": arm, "scope": issue["scope"],
            "family": issue["family"], "version": issue["version"], "teach": issue["teach"],
            "slice": issue["slice"], "passed": passed, "reason": reason,
            "memory_provenance": provenance, "memory_tokens": memory_tokens,
            "prompt_tokens": response.get("prompt_tokens", 0), "generated_tokens": response.get("generated_tokens", 0),
            "usable": response.get("usable", False), "strict_json": response.get("strict_json", False),
            "attempts": response.get("attempts", 0), "cross_scope_retrievals": getattr(system_obj, "cross_scope_retrievals", 0),
            "details": details,
        }
        active_label = None
        if arm == "akili" and not issue["teach"]:
            active = system_obj.active_record(issue["family"])
            active_label = (active or {}).get("decision_label")
        trace["active_decision_label"] = active_label
        trace["obsolete_memory"] = bool(
            arm == "akili" and not issue["teach"] and active_label != f"v{issue['version']}"
        )
        traces.append(trace)
    report = system_obj.report()
    return {"arm": arm, "traces": traces, "system_report": report}


def aggregate(run_data: Dict[int, Dict[str, Any]]) -> Dict[str, Any]:
    result: Dict[str, Any] = {"arms": {}, "integrity": {}, "performance": {}}
    for arm in ARMS:
        traces = [t for seed in run_data.values() for t in seed[arm]["traces"]]
        passed = sum(t["passed"] for t in traces)
        by_slice: Dict[str, Dict[str, Any]] = {}
        for slice_name in sorted({t["slice"] for t in traces}):
            rows = [t for t in traces if t["slice"] == slice_name]
            by_slice[slice_name] = {"issues": len(rows), "passed": sum(r["passed"] for r in rows), "rate": sum(r["passed"] for r in rows) / len(rows)}
        result["arms"][arm] = {
            "issues": len(traces), "passed": passed, "accuracy": passed / len(traces),
            "prompt_tokens": sum(t["prompt_tokens"] for t in traces),
            "generated_tokens": sum(t["generated_tokens"] for t in traces),
            "memory_tokens": sum(t["memory_tokens"] for t in traces),
            "retries": sum(max(0, t["attempts"] - 1) for t in traces),
            "usable_rate": sum(t["usable"] for t in traces) / len(traces),
            "strict_first_rate": sum(t["strict_json"] for t in traces) / len(traces),
            "obsolete_retrievals": sum(t["obsolete_memory"] for t in traces),
            "by_slice": by_slice,
        }
    all_traces = [t for seed in run_data.values() for arm in ARMS for t in seed[arm]["traces"]]
    integrity = {
        "three_seed_locked_design": len(run_data) == 3,
        "all_arm_issue_counts_equal": len({len(run_data[s][a]["traces"]) for s in run_data for a in ARMS}) == 1,
        "environment_hashes_present": all(seed_data.get("environment_hash") for seed_data in run_data.values()),
        "cross_scope_retrieval_zero": all(t["cross_scope_retrievals"] == 0 for t in all_traces),
        "obsolete_retrieval_zero": all(not t["obsolete_memory"] for t in all_traces if t["arm"] == "akili"),
        "akili_teaching_template_coverage": all(t["memory_provenance"] == "CURRENT_INSTRUCTION_TEMPLATE" for t in all_traces if t["arm"] == "akili" and t["teach"]),
        "template_only_has_no_persistent_memory": all(t["memory_provenance"] in {"CURRENT_INSTRUCTION_TEMPLATE", "NO_MEMORY"} for t in all_traces if t["arm"] == "template_only"),
        "akili_recall_uses_persistent_template": all(t["memory_provenance"] == "PERSISTENT_SCHEMA_TEMPLATE" for t in all_traces if t["arm"] == "akili" and not t["teach"]),
        "all_system_audits_valid": all(run_data[s][a]["system_report"].get("audit_valid", True) for s in run_data for a in ARMS),
        "all_system_states_bounded": all(run_data[s][a]["system_report"].get("state_bounded", True) for s in run_data for a in ARMS),
    }
    result["integrity"] = integrity
    ak = result["arms"]["akili"]
    icl = result["arms"]["bounded_icl"]
    prompt_reduction = 1 - ak["prompt_tokens"] / max(icl["prompt_tokens"], 1)
    perf = {
        "akili_accuracy_at_least_90": ak["accuracy"] >= 0.90,
        "akili_within_5pp_of_icl": ak["accuracy"] + 0.05 >= icl["accuracy"],
        "akili_acquisition_at_least_90": statistics.fmean([ak["by_slice"][x]["rate"] for x in ("acquisition_1", "acquisition_2")]) >= 0.90,
        "akili_return_at_least_90": ak["by_slice"]["return_after_interruption"]["rate"] >= 0.90,
        "akili_post_supersession_at_least_90": ak["by_slice"]["post_supersession_return"]["rate"] >= 0.90,
        "prompt_reduction_at_least_70": prompt_reduction >= 0.70,
        "obsolete_retrieval_zero": ak["obsolete_retrievals"] == 0,
        "cross_scope_retrieval_zero": integrity["cross_scope_retrieval_zero"],
        "all_integrity_pass": all(integrity.values()),
    }
    result["performance"] = {"criteria": perf, "prompt_reduction": prompt_reduction, "PASS": all(perf.values())}
    return result


def run(phase: str, mode: str, output: Path, model_name: str, budget_icl: int, budget_akili: int) -> Dict[str, Any]:
    assert phase in LOCKED_PHASE_SEEDS
    seeds = LOCKED_PHASE_SEEDS[phase]
    output.mkdir(parents=True, exist_ok=True)
    model: Any = MockModel() if mode == "mock" else HFModel(model_name)
    run_data: Dict[int, Dict[str, Any]] = {}
    for seed in seeds:
        env = make_env(seed)
        run_data[seed] = {"environment_hash": env["environment_hash"]}
        for arm in ARMS:
            print(f"seed={seed} arm={arm}", flush=True)
            run_data[seed][arm] = run_arm(env, arm, model, budget_icl, budget_akili)
            (output / f"seed{seed}_{arm}.json").write_text(json.dumps(run_data[seed][arm], indent=2), encoding="utf-8")
    summary = aggregate(run_data)
    receipt = {
        "protocol": PROTOCOL, "phase": phase, "mode": mode, "seeds": seeds,
        "model": model_name if mode == "real" else "prompt-path mock",
        "budgets": {"bounded_icl": budget_icl, "akili": budget_akili},
        "environment_hashes": {str(s): run_data[s]["environment_hash"] for s in seeds},
        "summary": summary,
    }
    receipt["implementation_fingerprint"] = canonical_hash({
        "protocol": PROTOCOL,
        "families": FAMILIES,
        "templates": {f: render_template(f) for f in FAMILIES},
        "scorer_source": ast.get_source_segment(open(__file__, encoding="utf-8").read(), ast.parse(open(__file__, encoding="utf-8").read()).body[0]) if False else "see file hash",
    })
    receipt["script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (output / "FINAL_RECEIPT.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return receipt


def parse_args(argv: Optional[Iterable[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--phase", choices=LOCKED_PHASE_SEEDS, default=os.getenv("AKILI_V4_PHASE", "development"))
    p.add_argument("--mode", choices=["mock", "real"], default=os.getenv("AKILI_V4_MODE", "mock"))
    p.add_argument("--output", type=Path, default=Path(os.getenv("AKILI_V4_OUTPUT", "./akili_v4_output")))
    p.add_argument("--model", default=os.getenv("AKILI_V4_MODEL", "Qwen/Qwen3-4B"))
    p.add_argument("--icl-budget", type=int, default=int(os.getenv("AKILI_V4_ICL_BUDGET", "1024")))
    p.add_argument("--akili-budget", type=int, default=int(os.getenv("AKILI_V4_AKILI_BUDGET", "288")))
    return p.parse_args(argv)


if __name__ == "__main__":
    args = parse_args()
    receipt = run(args.phase, args.mode, args.output, args.model, args.icl_budget, args.akili_budget)
    raise SystemExit(0 if receipt["summary"]["integrity"] and all(receipt["summary"]["integrity"].values()) else 2)
