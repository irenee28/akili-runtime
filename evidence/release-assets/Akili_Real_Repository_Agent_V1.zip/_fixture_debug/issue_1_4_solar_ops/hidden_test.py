import unittest
from solar_ops.config import resolve_setting
class HiddenTests(unittest.TestCase):
    def test_precedence(self):
        values = {"cli":"CLI", "env":"ENV", "file_value":"FILE", "default":"DEF"}
        self.assertEqual(resolve_setting(values["cli"], values["env"], values["file_value"], values["default"]), values['cli'])
        values['cli'] = None
        self.assertEqual(resolve_setting(values["cli"], values["env"], values["file_value"], values["default"]), values['env'])
if __name__ == "__main__": unittest.main()
