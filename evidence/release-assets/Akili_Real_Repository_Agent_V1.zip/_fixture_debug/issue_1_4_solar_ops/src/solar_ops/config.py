def resolve_setting(cli, env, file_value, default):
    for value in (cli, env, file_value, default):
        if value is not None:
            return value
    return None
