def validate_voltage(value):
    raise NotImplementedError('implement')
