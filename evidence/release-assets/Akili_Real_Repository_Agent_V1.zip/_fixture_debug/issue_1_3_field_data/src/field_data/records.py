def serialize_observation(record):
    return {
        'asset_id_v1': record['asset_v1'],
        'measurement_v1': record['reading_v1'],
    }
