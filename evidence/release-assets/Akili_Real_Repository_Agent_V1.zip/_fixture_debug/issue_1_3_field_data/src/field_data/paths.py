def artifact_path(root, project, name):
    raise NotImplementedError('implement')
