import unittest
from field_data.records import serialize_observation
class HiddenTests(unittest.TestCase):
    def test_mapping(self):
        record = {'asset_v1': 12, 'reading_v1': 7.5, "noise": True}
        self.assertEqual(serialize_observation(record), {'asset_id_v1': 12, 'measurement_v1': 7.5})
if __name__ == "__main__": unittest.main()
