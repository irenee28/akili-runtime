def is_complete(record, required):
    return all(key in record for key in required)
