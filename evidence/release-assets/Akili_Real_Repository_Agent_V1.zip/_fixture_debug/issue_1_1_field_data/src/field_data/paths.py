def artifact_path(root, project, name):
    return f"{root}/{project}/inspection_{name}.txt"
