def serialize_observation(record):
    raise NotImplementedError('implement')
