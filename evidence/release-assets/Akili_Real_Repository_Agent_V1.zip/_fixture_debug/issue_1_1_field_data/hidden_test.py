import unittest
from field_data.paths import artifact_path
class HiddenTests(unittest.TestCase):
    def test_path(self):
        self.assertEqual(artifact_path("/tmp", "site-a", "panel"), '/tmp/site-a/inspection_panel.txt')
if __name__ == "__main__": unittest.main()
