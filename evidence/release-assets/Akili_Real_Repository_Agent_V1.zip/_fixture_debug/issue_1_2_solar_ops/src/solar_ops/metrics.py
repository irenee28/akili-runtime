def efficiency(output, input_value):
    return output / input_value if input_value else 0.0
