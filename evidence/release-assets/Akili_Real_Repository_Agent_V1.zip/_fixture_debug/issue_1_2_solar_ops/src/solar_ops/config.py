def resolve_setting(cli, env, file_value, default):
    raise NotImplementedError('implement')
