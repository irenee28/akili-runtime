def validate_voltage(value):
    if value < 11 or value > 111:
        raise ValueError('voltage-policy-v1')
    return value
