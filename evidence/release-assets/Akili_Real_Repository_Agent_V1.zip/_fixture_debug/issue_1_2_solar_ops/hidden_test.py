import unittest
from solar_ops.validators import validate_voltage
class HiddenTests(unittest.TestCase):
    def test_range(self):
        self.assertEqual(validate_voltage(11), 11)
        self.assertEqual(validate_voltage(111), 111)
    def test_outside(self):
        for value in (10, 112):
            with self.assertRaisesRegex(ValueError, 'voltage-policy-v1'):
                validate_voltage(value)
if __name__ == "__main__": unittest.main()
