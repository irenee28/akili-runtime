# solar_ops
Small solar operations utility package used by the Akili benchmark.
