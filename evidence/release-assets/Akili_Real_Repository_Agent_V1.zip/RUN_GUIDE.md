# Akili Real-Repository Coding Agent Run Guide

## Goal
Evaluate repository switching, restoration and supersession across two multi-file Python repositories. Candidate functions are inserted into fresh repository copies and judged by hidden `unittest` suites.

## Procedure
1. Upload `Akili_Real_Repository_Coding_Agent_Colab.ipynb` to Colab.
2. Select a CUDA GPU.
3. Leave `AKILI_REPO_PHASE` unset for development seeds 1-3.
4. Run all cells. The notebook first compiles the embedded sources and runs a mock plus a real-subprocess fixture.
5. The real Qwen run evaluates stateless, bounded ICL and Akili.
6. Do not expose or insert hidden tests into prompts.
7. Preserve the output directory and `FINAL_RECEIPT.json`.
8. Run held-out seeds 4-6 only after freezing development.

## Frozen criteria
- Akili test-pass accuracy >= 90%
- within 5 percentage points of bounded ICL or better
- return after repository switch >= 90%
- post-supersession return >= 90%
- prompt reduction >= 60%
- obsolete and cross-repository retrieval = 0
- all integrity gates pass
