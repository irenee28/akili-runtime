#!/usr/bin/env python3
"""Akili real-repository coding-agent benchmark.

Creates two small, multi-file Python repositories, applies model-generated
functions, and validates them with hidden unittest suites in isolated temporary
copies. The public issue prompt never contains the tests.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from akili_v311a_core import AkiliCore, BoundedICL, Stateless, truncate_to_budget

PROTOCOL = "akili-real-repo-agent-v1"
LOCKED_PHASE_SEEDS = {"development": [1, 2, 3], "heldout": [4, 5, 6]}
ARMS = ["stateless", "bounded_icl", "akili"]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_hash(obj: Any) -> str:
    return sha256_bytes(json.dumps(obj, sort_keys=True, default=str).encode())


def token_count_approx(text: str) -> int:
    return max(0, (len(text or "") + 3) // 4)


FAMILY_META = {
    "solar_voltage_validation": {
        "repo": "solar_ops", "module": "src/solar_ops/validators.py", "function": "validate_voltage",
        "shape": "unary_voltage_validation",
        "template": '''def validate_voltage(value):
    if value < <LOWER_BOUND> or value > <UPPER_BOUND>:
        raise <EXCEPTION_TYPE>(<MESSAGE>)
    return value''',
    },
    "solar_config_precedence": {
        "repo": "solar_ops", "module": "src/solar_ops/config.py", "function": "resolve_setting",
        "shape": "first_non_null_setting",
        "template": '''def resolve_setting(cli, env, file_value, default):
    for value in (<SOURCE_1>, <SOURCE_2>, <SOURCE_3>, <SOURCE_4>):
        if value is not None:
            return value
    return None''',
    },
    "field_record_serialization": {
        "repo": "field_data", "module": "src/field_data/records.py", "function": "serialize_observation",
        "shape": "observation_to_dict",
        "template": '''def serialize_observation(record):
    return {
        <OUTPUT_KEY_1>: record[<INPUT_KEY_1>],
        <OUTPUT_KEY_2>: record[<INPUT_KEY_2>],
    }''',
    },
    "field_artifact_naming": {
        "repo": "field_data", "module": "src/field_data/paths.py", "function": "artifact_path",
        "shape": "artifact_path_naming",
        "template": '''def artifact_path(root, project, name):
    return f"{root}/{project}/<PREFIX>_{name}.<EXTENSION>"''',
    },
}
FAMILIES = list(FAMILY_META)


def params_for(family: str, version: int, seed: int) -> Dict[str, Any]:
    rng = random.Random(seed * 10_000 + FAMILIES.index(family) * 100 + version)
    if family == "solar_voltage_validation":
        low = rng.choice([0, 10, 50]) + version
        return {"low": low, "high": low + rng.choice([100, 200, 400]), "exception": "ValueError" if version == 1 else "RuntimeError", "message": f"voltage-policy-v{version}"}
    if family == "solar_config_precedence":
        return {"order": ["cli", "env", "file_value", "default"] if version == 1 else ["env", "file_value", "cli", "default"]}
    if family == "field_record_serialization":
        return {"in1": f"asset_v{version}", "in2": f"reading_v{version}", "out1": f"asset_id_v{version}", "out2": f"measurement_v{version}"}
    if family == "field_artifact_naming":
        return {"prefix": "inspection" if version == 1 else "verified", "ext": ["json", "txt", "dat"][seed % 3]}
    raise KeyError(family)


def public_rule(family: str, p: Dict[str, Any]) -> str:
    if family == "solar_voltage_validation":
        return f"accept inclusive voltage range [{p['low']}, {p['high']}]; otherwise raise {p['exception']} with {p['message']!r}"
    if family == "solar_config_precedence":
        return "setting precedence is " + " > ".join(p["order"])
    if family == "field_record_serialization":
        return f"map {p['in1']!r},{p['in2']!r} to {p['out1']!r},{p['out2']!r}"
    if family == "field_artifact_naming":
        return f"artifact path uses {p['prefix']}_<name>.{p['ext']}"
    raise KeyError(family)


def expected_code(family: str, p: Dict[str, Any]) -> str:
    fn = FAMILY_META[family]["function"]
    if family == "solar_voltage_validation":
        return f'''def {fn}(value):
    if value < {p["low"]!r} or value > {p["high"]!r}:
        raise {p["exception"]}({p["message"]!r})
    return value
'''
    if family == "solar_config_precedence":
        return f'''def {fn}(cli, env, file_value, default):
    for value in ({", ".join(p["order"])}):
        if value is not None:
            return value
    return None
'''
    if family == "field_record_serialization":
        return f'''def {fn}(record):
    return {{
        {p["out1"]!r}: record[{p["in1"]!r}],
        {p["out2"]!r}: record[{p["in2"]!r}],
    }}
'''
    if family == "field_artifact_naming":
        return f'''def {fn}(root, project, name):
    return f"{{root}}/{{project}}/{p["prefix"]}_{{name}}.{p["ext"]}"
'''
    raise KeyError(family)


def current_template(family: str) -> str:
    return (
        "MEMORY TYPE: CURRENT_INSTRUCTION_TEMPLATE\n"
        "Source: deterministic renderer from current repository metadata.\n"
        "Replace placeholders only with values from the current issue.\n"
        + FAMILY_META[family]["template"]
    )


def make_issues(seed: int) -> List[Dict[str, Any]]:
    stages = [
        [(f, 1, True, "acquisition_1") for f in FAMILIES],
        [(f, 1, True, "acquisition_2") for f in reversed(FAMILIES)],
        [(f, 1, False, "return_after_repo_switch") for f in FAMILIES],
        [(f, 2, True, "supersession_1") for f in reversed(FAMILIES)],
        [(f, 2, True, "supersession_2") for f in FAMILIES],
        [(f, 2, False, "post_supersession_return") for f in reversed(FAMILIES)],
    ]
    rng = random.Random(seed)
    result: List[Dict[str, Any]] = []
    issue_id = 0
    for stage in stages:
        stage = list(stage)
        rng.shuffle(stage)
        for family, version, teach, slice_name in stage:
            issue_id += 1
            p = params_for(family, version, seed)
            meta = FAMILY_META[family]
            issue = {
                "id": issue_id, "seed": seed, "family": family, "version": version,
                "repo": meta["repo"], "module": meta["module"], "function": meta["function"],
                "shape": meta["shape"], "teach": teach, "slice": slice_name,
                "params": p, "rule": public_rule(family, p),
                "expected_code": expected_code(family, p),
            }
            result.append(issue)
    return result


def repo_files(repo: str) -> Dict[str, str]:
    if repo == "solar_ops":
        return {
            "README.md": "# solar_ops\nSmall solar operations utility package used by the Akili benchmark.\n",
            "src/solar_ops/__init__.py": "from .validators import validate_voltage\nfrom .config import resolve_setting\n",
            "src/solar_ops/validators.py": "def validate_voltage(value):\n    raise NotImplementedError('implement')\n",
            "src/solar_ops/config.py": "def resolve_setting(cli, env, file_value, default):\n    raise NotImplementedError('implement')\n",
            "src/solar_ops/metrics.py": "def efficiency(output, input_value):\n    return output / input_value if input_value else 0.0\n",
        }
    if repo == "field_data":
        return {
            "README.md": "# field_data\nSmall field-data utility package used by the Akili benchmark.\n",
            "src/field_data/__init__.py": "from .records import serialize_observation\nfrom .paths import artifact_path\n",
            "src/field_data/records.py": "def serialize_observation(record):\n    raise NotImplementedError('implement')\n",
            "src/field_data/paths.py": "def artifact_path(root, project, name):\n    raise NotImplementedError('implement')\n",
            "src/field_data/quality.py": "def is_complete(record, required):\n    return all(key in record for key in required)\n",
        }
    raise KeyError(repo)


def repo_context(repo: str) -> str:
    parts = []
    for path, text in sorted(repo_files(repo).items()):
        parts.append(f"--- {path} ---\n{text}")
    return "\n".join(parts)


def hidden_test_source(issue: Dict[str, Any]) -> str:
    p, module, fn = issue["params"], issue["module"].replace("src/", "").replace(".py", "").replace("/", "."), issue["function"]
    if issue["family"] == "solar_voltage_validation":
        return f'''import unittest
from {module} import {fn}
class HiddenTests(unittest.TestCase):
    def test_range(self):
        self.assertEqual({fn}({p["low"]}), {p["low"]})
        self.assertEqual({fn}({p["high"]}), {p["high"]})
    def test_outside(self):
        for value in ({p["low"] - 1}, {p["high"] + 1}):
            with self.assertRaisesRegex({p["exception"]}, {p["message"]!r}):
                {fn}(value)
if __name__ == "__main__": unittest.main()
'''
    if issue["family"] == "solar_config_precedence":
        first, second = p["order"][:2]
        return f'''import unittest
from {module} import {fn}
class HiddenTests(unittest.TestCase):
    def test_precedence(self):
        values = {{"cli":"CLI", "env":"ENV", "file_value":"FILE", "default":"DEF"}}
        self.assertEqual({fn}(values["cli"], values["env"], values["file_value"], values["default"]), values[{first!r}])
        values[{first!r}] = None
        self.assertEqual({fn}(values["cli"], values["env"], values["file_value"], values["default"]), values[{second!r}])
if __name__ == "__main__": unittest.main()
'''
    if issue["family"] == "field_record_serialization":
        return f'''import unittest
from {module} import {fn}
class HiddenTests(unittest.TestCase):
    def test_mapping(self):
        record = {{{p["in1"]!r}: 12, {p["in2"]!r}: 7.5, "noise": True}}
        self.assertEqual({fn}(record), {{{p["out1"]!r}: 12, {p["out2"]!r}: 7.5}})
if __name__ == "__main__": unittest.main()
'''
    if issue["family"] == "field_artifact_naming":
        return f'''import unittest
from {module} import {fn}
class HiddenTests(unittest.TestCase):
    def test_path(self):
        self.assertEqual({fn}("/tmp", "site-a", "panel"), {f"/tmp/site-a/{p['prefix']}_panel.{p['ext']}"!r})
if __name__ == "__main__": unittest.main()
'''
    raise KeyError(issue["family"])


FORBIDDEN = (ast.Import, ast.ImportFrom, ast.While, ast.With, ast.AsyncWith, ast.ClassDef, ast.Lambda, ast.Global, ast.Nonlocal, ast.Delete, ast.Yield, ast.YieldFrom, ast.Await)


def normalize_code(text: str) -> str:
    text = (text or "").strip()
    if text.startswith("```"):
        lines = text.splitlines()[1:]
        if lines and lines[-1].strip() == "```": lines = lines[:-1]
        text = "\n".join(lines).strip()
    return text


def validate_candidate(code: str, expected_function: str) -> Tuple[bool, str]:
    try: tree = ast.parse(code)
    except SyntaxError as exc: return False, f"syntax:{exc}"
    if len(tree.body) != 1 or not isinstance(tree.body[0], ast.FunctionDef): return False, "one function required"
    if tree.body[0].name != expected_function: return False, "wrong function name"
    for node in ast.walk(tree):
        if isinstance(node, FORBIDDEN): return False, f"forbidden:{type(node).__name__}"
        if isinstance(node, ast.Name) and node.id.startswith("__"): return False, "dunder name"
        if isinstance(node, ast.Attribute) and node.attr.startswith("__"): return False, "dunder attr"
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id not in {"range", "len", "ValueError", "RuntimeError"}: return False, f"call:{node.func.id}"
            if isinstance(node.func, ast.Attribute) and node.func.attr not in {"pop"}: return False, f"method:{node.func.attr}"
    return True, "ok"


def replace_function(module_text: str, function_name: str, candidate: str) -> str:
    tree = ast.parse(module_text)
    target = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == function_name), None)
    if target is None: raise ValueError(f"function {function_name} not found")
    lines = module_text.splitlines()
    start = target.lineno - 1
    end = target.end_lineno or target.lineno
    return "\n".join(lines[:start] + candidate.strip().splitlines() + lines[end:]) + "\n"


def evaluate_in_repo(issue: Dict[str, Any], candidate: str, work_root: Path) -> Tuple[bool, str, str]:
    candidate = normalize_code(candidate)
    ok, reason = validate_candidate(candidate, issue["function"])
    if not ok: return False, reason, ""
    repo_dir = work_root / f"issue_{issue['seed']}_{issue['id']}_{issue['repo']}"
    if repo_dir.exists(): shutil.rmtree(repo_dir)
    for path, text in repo_files(issue["repo"]).items():
        target = repo_dir / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
    module_path = repo_dir / issue["module"]
    module_path.write_text(replace_function(module_path.read_text(), issue["function"], candidate), encoding="utf-8")
    tests = repo_dir / "hidden_test.py"
    tests.write_text(hidden_test_source(issue), encoding="utf-8")
    env = os.environ.copy()
    env["PYTHONPATH"] = str(repo_dir / "src")
    try:
        proc = subprocess.run([sys.executable, "-m", "unittest", "-q", "hidden_test.py"], cwd=repo_dir, env=env, capture_output=True, text=True, timeout=8)
    except subprocess.TimeoutExpired: return False, "test timeout", ""
    output = (proc.stdout + "\n" + proc.stderr).strip()
    return proc.returncode == 0, "pass" if proc.returncode == 0 else "hidden tests failed", output


def derive_repo(_stats: Dict[str, Any], _profile: Dict[str, Any], features: Dict[str, Any]):
    if not features.get("teach"): return None
    family = features["family"]
    return {
        "family": family,
        "rule": features["rule"],
        "decision_label": f"v{features['version']}",
        "lifecycle_state": "VERIFIED",
        "evidence": {"count": features["evidence_count"], "version": features["version"]},
        "admit_threshold": 2,
        "schema_template": FAMILY_META[family]["template"],
        "template_metadata": {"source": "repo_public_metadata_renderer", "shape_key": FAMILY_META[family]["shape"], "value_free": True},
    }


def prompt_for(issue: Dict[str, Any], memory: str) -> Tuple[str, str]:
    system = "You are editing a real Python repository. Return only JSON with string field content containing exactly one replacement function."
    teaching = f"\nCURRENT MAINTAINER CONVENTION:\n{issue['rule']}\n" if issue["teach"] else ""
    user = (
        f"REPOSITORY: {issue['repo']}\nTARGET FILE: {issue['module']}\nTARGET FUNCTION: {issue['function']}\n"
        + teaching
        + "CURRENT PARAMETERS JSON:\n" + json.dumps(issue["params"], sort_keys=True) + "\n"
        + "VISIBLE REPOSITORY FILES:\n" + repo_context(issue["repo"]) + "\n"
        + ("ADAPTATION MEMORY:\n" + memory + "\n" if memory else "")
        + "Return the replacement function. Hidden tests are not visible and must not be guessed or modified."
    )
    return system, user


class MockModel:
    def __call__(self, _system: str, user: str, issue: Dict[str, Any]) -> Dict[str, Any]:
        if "CURRENT_INSTRUCTION_TEMPLATE" in user or "SCHEMA_TEMPLATE" in user:
            content = issue["expected_code"]
        else:
            content = f"def {issue['function']}(*args):\n    return None\n"
        return {"content": content, "prompt_tokens": token_count_approx(user), "generated_tokens": token_count_approx(content), "usable": True, "strict_json": True, "attempts": 1}


class HFModel:
    def __init__(self, model_name: str):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
        assert torch.cuda.is_available()
        self.torch = torch
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        quant = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=dtype)
        self.tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)
        if self.tokenizer.pad_token_id is None: self.tokenizer.pad_token_id = self.tokenizer.eos_token_id
        self.model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", quantization_config=quant, torch_dtype=dtype)
        self.model.eval()
    def count(self, text: str) -> int: return len(self.tokenizer.encode(text or "", add_special_tokens=False))
    def _parse(self, raw: str) -> Tuple[Optional[str], bool]:
        try:
            obj = json.loads(raw.strip())
            if isinstance(obj, dict) and isinstance(obj.get("content"), str): return obj["content"], True
        except Exception: pass
        decoder = json.JSONDecoder()
        for m in re.finditer(r"\{", raw):
            try:
                obj, _ = decoder.raw_decode(raw[m.start():])
                if isinstance(obj, dict) and isinstance(obj.get("content"), str): return obj["content"], False
            except Exception: pass
        lines = raw.splitlines()
        for end in range(len(lines), 0, -1):
            candidate = "\n".join(lines[:end]).strip()
            try:
                tree = ast.parse(candidate)
                if len(tree.body) == 1 and isinstance(tree.body[0], ast.FunctionDef): return candidate, False
            except Exception: pass
        return None, False
    def __call__(self, system: str, user: str, issue: Dict[str, Any]) -> Dict[str, Any]:
        attempts = total_prompt = total_generated = 0
        raws = []
        for retry in range(2):
            attempts += 1
            current_user = user if retry == 0 else user + "\nPrior output invalid. Return only {\"content\": \"def ...\"}."
            prompt = self.tokenizer.apply_chat_template([{"role":"system","content":system},{"role":"user","content":current_user}], tokenize=False, add_generation_prompt=True, enable_thinking=False)
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
            total_prompt += int(inputs["input_ids"].shape[-1])
            with self.torch.inference_mode(): out = self.model.generate(**inputs, max_new_tokens=420, do_sample=False, pad_token_id=self.tokenizer.pad_token_id)
            gen = out[0, inputs["input_ids"].shape[-1]:]
            total_generated += int(gen.shape[-1])
            raw = self.tokenizer.decode(gen, skip_special_tokens=True); raws.append(raw)
            content, strict = self._parse(raw)
            if content is not None: return {"content": content, "prompt_tokens": total_prompt, "generated_tokens": total_generated, "usable": True, "strict_json": strict, "attempts": attempts, "raw_outputs": raws}
        return {"content":"", "prompt_tokens":total_prompt, "generated_tokens":total_generated, "usable":False, "strict_json":False, "attempts":attempts, "raw_outputs":raws}


def run_arm(issues: List[Dict[str, Any]], arm: str, model: Any, work_root: Path, icl_budget: int, akili_budget: int, fast_mock: bool = False) -> Dict[str, Any]:
    count_fn = getattr(model, "count", token_count_approx)
    if arm == "stateless": sysobj: Any = Stateless(count_fn)
    elif arm == "bounded_icl": sysobj = BoundedICL(icl_budget, count_fn)
    elif arm == "akili": sysobj = AkiliCore(akili_budget, count_fn, derive_repo, min_evidence=2, max_profiles=4, max_versions=48, recent_window=10, max_stats_keys=64, max_retrieval_log=256)
    else: raise KeyError(arm)
    evidence = defaultdict(int)
    traces = []
    active_versions: Dict[Tuple[str,str], int] = {}
    for issue in issues:
        if hasattr(sysobj, "switch_entity"): sysobj.switch_entity(issue["repo"])
        memory, provenance, details = "", "NO_MEMORY", {}
        if arm == "bounded_icl": memory, provenance = sysobj.memory_prompt(), "RAW_HISTORY"
        elif arm == "akili":
            if issue["teach"]: memory, provenance = current_template(issue["family"]), "CURRENT_INSTRUCTION_TEMPLATE"
            else:
                memory, details = sysobj.retrieval_context(issue["family"], issue["shape"])
                provenance = details.get("primary_memory_class", "NO_MEMORY")
        memory, memory_tokens = truncate_to_budget(memory, akili_budget if arm == "akili" else icl_budget, count_fn)
        system_prompt, user_prompt = prompt_for(issue, memory)
        response = model(system_prompt, user_prompt, issue)
        if fast_mock:
            candidate = normalize_code(response.get("content", ""))
            ast_ok, ast_reason = validate_candidate(candidate, issue["function"])
            passed = ast_ok and candidate.strip() == issue["expected_code"].strip()
            reason = "pass" if passed else (ast_reason if not ast_ok else "mock hidden-test mismatch")
            test_output = "FAST_MOCK_EQUIVALENCE"
        else:
            passed, reason, test_output = evaluate_in_repo(issue, response.get("content", ""), work_root / arm)
        if arm == "bounded_icl":
            sysobj.observe_episode(user_prompt + "\nASSISTANT:\n" + response.get("content", "") + f"\nVERIFIER:{'PASS' if passed else 'FAIL'}", {}, issue["repo"], "PASS" if passed else "FAIL")
        elif arm == "akili":
            key = (issue["repo"], issue["family"], issue["version"])
            if issue["teach"]: evidence[key] += 1
            sysobj.observe_episode(
                f"{issue['family']} v{issue['version']}",
                {"teach": issue["teach"], "family": issue["family"], "version": issue["version"], "rule": issue["rule"], "evidence_count": evidence[key], f"latest_{issue['family']}_version": issue["version"]},
                issue["repo"], "PASS" if passed else "FAIL",
            )
            if issue["teach"] and evidence[key] >= 2: active_versions[(issue["repo"], issue["family"])] = issue["version"]
        active_label = None
        if arm == "akili" and not issue["teach"]:
            active = sysobj.active_record(issue["family"])
            active_label = (active or {}).get("decision_label")
        obsolete = bool(arm == "akili" and not issue["teach"] and active_label != f"v{issue['version']}")
        traces.append({
            "issue_id": issue["id"], "seed": issue["seed"], "arm": arm, "repo": issue["repo"], "family": issue["family"], "version": issue["version"],
            "teach": issue["teach"], "slice": issue["slice"], "passed": passed, "reason": reason, "test_output": test_output[-1000:],
            "memory_provenance": provenance, "memory_tokens": memory_tokens, "prompt_tokens": response.get("prompt_tokens",0), "generated_tokens": response.get("generated_tokens",0),
            "usable": response.get("usable",False), "strict_json": response.get("strict_json",False), "attempts": response.get("attempts",0),
            "obsolete_memory": obsolete, "active_decision_label": active_label, "details": details,
        })
    return {"arm": arm, "traces": traces, "system_report": sysobj.report()}


def aggregate(data: Dict[int, Dict[str, Any]]) -> Dict[str, Any]:
    out = {"arms": {}, "integrity": {}, "performance": {}}
    for arm in ARMS:
        rows = [t for seed in data.values() for t in seed[arm]["traces"]]
        slices = {}
        for name in sorted({r["slice"] for r in rows}):
            subset = [r for r in rows if r["slice"] == name]
            slices[name] = {"issues":len(subset), "passed":sum(r["passed"] for r in subset), "rate":sum(r["passed"] for r in subset)/len(subset)}
        out["arms"][arm] = {
            "issues":len(rows), "passed":sum(r["passed"] for r in rows), "accuracy":sum(r["passed"] for r in rows)/len(rows),
            "prompt_tokens":sum(r["prompt_tokens"] for r in rows), "generated_tokens":sum(r["generated_tokens"] for r in rows),
            "memory_tokens":sum(r["memory_tokens"] for r in rows), "retries":sum(max(0,r["attempts"]-1) for r in rows),
            "usable_rate":sum(r["usable"] for r in rows)/len(rows), "strict_rate":sum(r["strict_json"] for r in rows)/len(rows),
            "obsolete_retrievals":sum(r["obsolete_memory"] for r in rows), "by_slice":slices,
        }
    all_rows = [r for seed in data.values() for arm in ARMS for r in seed[arm]["traces"]]
    integrity = {
        "locked_three_seed_design": len(data)==3,
        "equal_issue_counts": len({len(data[s][a]["traces"]) for s in data for a in ARMS})==1,
        "repo_fixture_hashes_present": all(data[s].get("fixture_hash") for s in data),
        "akili_teaching_template_exact": all(r["memory_provenance"]=="CURRENT_INSTRUCTION_TEMPLATE" for r in all_rows if r["arm"]=="akili" and r["teach"]),
        "akili_recall_persistent": all(r["memory_provenance"]=="PERSISTENT_SCHEMA_TEMPLATE" for r in all_rows if r["arm"]=="akili" and not r["teach"]),
        "obsolete_retrieval_zero": all(not r["obsolete_memory"] for r in all_rows if r["arm"]=="akili"),
        "cross_scope_zero": all(data[s]["akili"]["system_report"].get("cross_scope_retrievals",0)==0 for s in data),
        "audits_valid": all(data[s]["akili"]["system_report"].get("audit_valid",False) for s in data),
        "states_bounded": all(data[s][a]["system_report"].get("state_bounded",True) for s in data for a in ARMS),
    }
    out["integrity"] = integrity
    ak, icl = out["arms"]["akili"], out["arms"]["bounded_icl"]
    reduction = 1-ak["prompt_tokens"]/max(icl["prompt_tokens"],1)
    criteria = {
        "akili_accuracy_at_least_90": ak["accuracy"]>=0.90,
        "akili_within_5pp_icl": ak["accuracy"]+0.05>=icl["accuracy"],
        "return_after_switch_at_least_90": ak["by_slice"]["return_after_repo_switch"]["rate"]>=0.90,
        "post_supersession_at_least_90": ak["by_slice"]["post_supersession_return"]["rate"]>=0.90,
        "prompt_reduction_at_least_60": reduction>=0.60,
        "all_integrity_pass": all(integrity.values()),
    }
    out["performance"] = {"criteria":criteria, "prompt_reduction":reduction, "PASS":all(criteria.values())}
    return out


def run(phase: str, mode: str, output: Path, model_name: str, icl_budget: int, akili_budget: int) -> Dict[str, Any]:
    seeds = LOCKED_PHASE_SEEDS[phase]
    output = output.expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    work_root = output / "work"; work_root.mkdir(exist_ok=True)
    model: Any = MockModel() if mode=="mock" else HFModel(model_name)
    data: Dict[int, Dict[str, Any]] = {}
    fixture_hash = canonical_hash({repo:repo_files(repo) for repo in ("solar_ops","field_data")})
    tests_hash = canonical_hash({s:[hidden_test_source(i) for i in make_issues(s)] for s in seeds})
    execution_fixture = []
    if mode == "mock":
        fixture_root = work_root / "execution_fixture"
        for issue in make_issues(seeds[0]):
            if issue["slice"] == "acquisition_1":
                ok, reason, output_text = evaluate_in_repo(issue, issue["expected_code"], fixture_root)
                execution_fixture.append({"family": issue["family"], "passed": ok, "reason": reason})
        assert execution_fixture and all(row["passed"] for row in execution_fixture), execution_fixture
    for seed in seeds:
        issues = make_issues(seed)
        data[seed] = {"fixture_hash":fixture_hash, "tests_hash":tests_hash}
        for arm in ARMS:
            print(f"seed={seed} arm={arm}", flush=True)
            data[seed][arm] = run_arm(issues, arm, model, work_root/f"seed{seed}", icl_budget, akili_budget, fast_mock=(mode=="mock"))
            (output/f"seed{seed}_{arm}.json").write_text(json.dumps(data[seed][arm],indent=2),encoding="utf-8")
    summary = aggregate(data)
    receipt = {"protocol":PROTOCOL,"phase":phase,"mode":mode,"seeds":seeds,"model":model_name if mode=="real" else "prompt-path mock","fixture_hash":fixture_hash,"hidden_tests_hash":tests_hash,"execution_fixture":execution_fixture,"summary":summary,"script_sha256":sha256_bytes(Path(__file__).read_bytes())}
    (output/"FINAL_RECEIPT.json").write_text(json.dumps(receipt,indent=2),encoding="utf-8")
    print(json.dumps(summary,indent=2))
    return receipt


def parse_args(argv: Optional[Iterable[str]]=None) -> argparse.Namespace:
    p=argparse.ArgumentParser()
    p.add_argument("--phase",choices=LOCKED_PHASE_SEEDS,default=os.getenv("AKILI_REPO_PHASE","development"))
    p.add_argument("--mode",choices=["mock","real"],default=os.getenv("AKILI_REPO_MODE","mock"))
    p.add_argument("--output",type=Path,default=Path(os.getenv("AKILI_REPO_OUTPUT","./akili_repo_output")))
    p.add_argument("--model",default=os.getenv("AKILI_REPO_MODEL","Qwen/Qwen3-4B"))
    p.add_argument("--icl-budget",type=int,default=int(os.getenv("AKILI_REPO_ICL_BUDGET","1400")))
    p.add_argument("--akili-budget",type=int,default=int(os.getenv("AKILI_REPO_AKILI_BUDGET","320")))
    return p.parse_args(argv)

if __name__=="__main__":
    a=parse_args(); receipt=run(a.phase,a.mode,a.output,a.model,a.icl_budget,a.akili_budget)
    raise SystemExit(0 if all(receipt["summary"]["integrity"].values()) else 2)
