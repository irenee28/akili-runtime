# =============================================================================
# V3.1.1 SYSTEMS — independent instances, bounded ICL state, scoped Akili state.
# =============================================================================
import copy
import hashlib
import json
import re
import uuid


def truncate_to_budget(text, budget_tokens, count_fn):
    text = text or ""
    if budget_tokens <= 0:
        return "", 0
    if count_fn(text) <= budget_tokens:
        return text, count_fn(text)
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if count_fn(text[:mid]) <= budget_tokens:
            lo = mid
        else:
            hi = mid - 1
    fitted = text[:lo]
    used = count_fn(fitted)
    while fitted and used > budget_tokens:
        fitted = fitted[:-1]
        used = count_fn(fitted)
    return fitted, used


def fit_newest_to_budget(parts_newest_first, budget_tokens, count_fn, header=""):
    chosen = []
    base = header
    for part in parts_newest_first:
        candidate_parts = chosen + [part]
        body = "\n\n".join(candidate_parts)
        candidate = (base + "\n" + body).strip() if base else body
        if count_fn(candidate) <= budget_tokens:
            chosen.append(part)
            continue
        remaining = budget_tokens - count_fn((base + "\n" + "\n\n".join(chosen)).strip())
        if remaining > 0:
            fitted, _ = truncate_to_budget(part, remaining, count_fn)
            if fitted:
                chosen.append(fitted)
        break
    text = ((base + "\n") if base else "") + "\n\n".join(chosen)
    text = text.strip()
    text, used = truncate_to_budget(text, budget_tokens, count_fn)
    return text, used


class Stateless:
    name = "stateless"

    def __init__(self, count_fn):
        self.count = count_fn
        self.instance_id = uuid.uuid4().hex

    def memory_prompt(self):
        return ""

    def observe_episode(self, summary, features, entity_hint, outcome):
        return None

    def report(self):
        return {
            "instance_id": self.instance_id,
            "stored_memory_chars": 0,
            "stored_memory_tokens": 0,
            "active_rules": 0,
            "admitted_total": 0,
            "superseded": 0,
        }


class BoundedICL:
    name = "bounded_icl"

    def __init__(self, budget_tokens, count_fn):
        self.budget = budget_tokens
        self.count = count_fn
        self.history = []
        self.instance_id = uuid.uuid4().hex

    def _render(self):
        if not self.history:
            return "", 0
        return fit_newest_to_budget(
            list(reversed(self.history)), self.budget, self.count,
            header="RECENT RAW EPISODE HISTORY:",
        )

    def _trim_state(self):
        while len(self.history) > 1:
            blob, used = self._render()
            if used <= self.budget and self.count("\n\n".join(self.history)) <= self.budget:
                break
            self.history.pop(0)
        if self.history:
            latest, _ = truncate_to_budget(self.history[-1], self.budget, self.count)
            self.history[-1] = latest

    def memory_prompt(self):
        return self._render()[0]

    def observe_episode(self, summary, features, entity_hint, outcome):
        self.history.append(str(summary))
        self._trim_state()

    def report(self):
        blob = "\n\n".join(self.history)
        prompt, prompt_tokens = self._render()
        return {
            "instance_id": self.instance_id,
            "history_entries": len(self.history),
            "stored_memory_chars": len(blob),
            "stored_memory_tokens": self.count(blob),
            "retrievable_tokens": prompt_tokens,
            "state_bounded": self.count(blob) <= self.budget,
            "active_rules": 0,
            "admitted_total": 0,
            "superseded": 0,
        }


_NAME_OK = re.compile(r"^[A-Za-z][A-Za-z0-9 .'\-_]{0,31}$")
_NAME_BAD_WORDS = frozenset({"policy", "stage", "schedule", "instance"})



class AkiliCore:
    name = "akili"

    def __init__(self, budget_tokens, count_fn, derive_fn, min_evidence=2,
                 max_profiles=16, max_versions=48, recent_window=10,
                 max_stats_keys=96, max_retrieval_log=512):
        self.budget = budget_tokens
        self.count = count_fn
        self.derive_fn = derive_fn
        self.min_evidence = min_evidence
        self.max_profiles = max_profiles
        self.max_versions = max_versions
        self.recent_window = recent_window
        self.max_stats_keys = max_stats_keys
        self.max_retrieval_log = max_retrieval_log
        self.instance_id = uuid.uuid4().hex
        self.profiles = {}
        self.current_key = None
        self.audit = []
        self.episode_count = 0
        self.cross_scope_retrievals = 0
        self.retrieval_log = []
        self._audit("RUN_START", {})

    def _audit(self, event, payload):
        body = {
            "seq": len(self.audit), "event": event, "episode": self.episode_count,
            "profile": self.current_key, "payload": payload,
            "prev_hash": self.audit[-1]["hash"] if self.audit else "GENESIS",
        }
        body["hash"] = hashlib.sha256(
            json.dumps(body, sort_keys=True, default=str).encode("utf-8")
        ).hexdigest()
        self.audit.append(body)

    def validate_chain(self):
        prev = "GENESIS"
        for entry in self.audit:
            body = {k: v for k, v in entry.items() if k != "hash"}
            if body["prev_hash"] != prev:
                return False
            expected = hashlib.sha256(
                json.dumps(body, sort_keys=True, default=str).encode("utf-8")
            ).hexdigest()
            if expected != entry["hash"]:
                return False
            prev = entry["hash"]
        return True

    def _new_profile(self, key, display):
        assert len(self.profiles) < self.max_profiles, "Akili profile bound exceeded"
        self.profiles[key] = {
            "key": key, "display": display, "status": "ACTIVE", "episodes": 0,
            "stats": {}, "recent_features": [], "versions": [], "version_seq": 0,
            "active_by_family": {}, "times_activated": 1,
        }

    def _accept_name(self, raw):
        name = str(raw or "").strip()
        if not _NAME_OK.match(name):
            return None
        if any(word in name.lower() for word in _NAME_BAD_WORDS):
            return None
        return name

    def switch_entity(self, raw_name):
        name = self._accept_name(raw_name)
        if name is None:
            key = "anon:" + hashlib.sha256(str(raw_name).encode()).hexdigest()[:16]
            display = None
        else:
            key = "name:" + hashlib.sha256(name.lower().encode()).hexdigest()[:16]
            display = name
        if key == self.current_key:
            return
        previous = self.current_key
        if previous is not None:
            self.profiles[previous]["status"] = "DORMANT"
        if key in self.profiles:
            self.profiles[key]["status"] = "ACTIVE"
            self.profiles[key]["times_activated"] += 1
            self.current_key = key
            self._audit("PROFILE_REACTIVATED", {"from": previous, "to": key, "display": display})
        else:
            self._new_profile(key, display)
            self.current_key = key
            self._audit("PROFILE_CREATED", {"from": previous, "to": key, "display": display})

    def _append_version(self, profile, version):
        if len(profile["versions"]) >= self.max_versions:
            removable = next((i for i, item in enumerate(profile["versions"])
                              if item["status"] in {"REJECTED", "SUPERSEDED"}), None)
            assert removable is not None, "Akili version bound exceeded with no removable record"
            removed = profile["versions"].pop(removable)
            self._audit("VERSION_EVICTED", {"version_hash": removed["hash"], "status": removed["status"]})
        profile["versions"].append(version)

    def observe_episode(self, summary, features, entity_hint, outcome):
        if self.current_key is None:
            self.switch_entity(entity_hint or "unnamed")
        self.episode_count += 1
        profile = self.profiles[self.current_key]
        profile["episodes"] += 1
        features = dict(features or {})
        profile["recent_features"].append(features)
        profile["recent_features"] = profile["recent_features"][-self.recent_window:]
        for key, value in features.items():
            if key not in profile["stats"]:
                assert len(profile["stats"]) < self.max_stats_keys, "Akili stats-key bound exceeded"
            if isinstance(value, (int, float)):
                profile["stats"][key] = profile["stats"].get(key, 0) + value
            elif key.startswith("latest_"):
                profile["stats"][key] = value
            else:
                profile["stats"].setdefault(key, value)
        self._audit("EPISODE_RECORDED", {"features": features, "outcome": outcome})
        candidates = self.derive_fn(profile["stats"], profile, features)
        if not candidates:
            return
        if isinstance(candidates, dict):
            candidates = [candidates]
        for candidate in candidates:
            self._process_candidate(profile, candidate)

    @staticmethod
    def _version_hash(version):
        body = {k: v for k, v in version.items() if k != "hash"}
        return hashlib.sha256(json.dumps(body, sort_keys=True, default=str).encode("utf-8")).hexdigest()

    def _process_candidate(self, profile, candidate):
        family = candidate.get("family", "general")
        lifecycle = candidate.get("lifecycle_state", "VERIFIED")
        assert lifecycle in {"PROVISIONAL", "VERIFIED", "CONFLICTED"}
        active = profile["active_by_family"].get(family)
        same_rule = active is not None and active["rule"] == candidate["rule"]
        same_state = active is not None and active.get("lifecycle_state", active["status"]) == lifecycle

        schema_template = candidate.get("schema_template")
        template_metadata = copy.deepcopy(candidate.get("template_metadata") or {})
        template_hash = hashlib.sha256(schema_template.encode("utf-8")).hexdigest() if schema_template else None
        verified_exemplar = candidate.get("verified_exemplar") or candidate.get("exemplar")
        verified_structural_exemplar = candidate.get("verified_structural_exemplar")
        exemplar_shape_key = candidate.get("exemplar_shape_key")

        if same_rule and same_state:
            changed = False
            old_hash = active["hash"]
            if schema_template and schema_template != active.get("schema_template"):
                active["schema_template"] = schema_template
                active["schema_template_hash"] = template_hash
                active["template_metadata"] = template_metadata
                changed = True
                self._audit("SCHEMA_TEMPLATE_ADDED", {
                    "family": family, "template_hash": template_hash,
                    "shape_key": template_metadata.get("shape_key"),
                    "source": template_metadata.get("source"),
                })
            if verified_exemplar and exemplar_shape_key:
                exemplars = active.setdefault("verified_exemplars", {})
                previous = exemplars.get(exemplar_shape_key)
                exemplar_hash = hashlib.sha256(verified_exemplar.encode("utf-8")).hexdigest()
                if not previous or previous.get("hash") != exemplar_hash:
                    structural_hash = (
                        hashlib.sha256(verified_structural_exemplar.encode("utf-8")).hexdigest()
                        if verified_structural_exemplar else None
                    )
                    exemplars[exemplar_shape_key] = {
                        "content": verified_exemplar,
                        "hash": exemplar_hash,
                        "structural_content": verified_structural_exemplar,
                        "structural_hash": structural_hash,
                        "shape_key": exemplar_shape_key,
                        "verified": True,
                    }
                    changed = True
                    self._audit("VERIFIED_EXEMPLAR_ADDED", {
                        "family": family, "shape_key": exemplar_shape_key,
                        "exemplar_hash": exemplar_hash,
                    })
            if changed:
                active["hash"] = self._version_hash(active)
                self._audit("ACTIVE_RECORD_UPDATED", {
                    "family": family, "old_hash": old_hash, "new_hash": active["hash"],
                })
            else:
                self._audit("CANDIDATE_DUPLICATE", {
                    "family": family, "lifecycle_state": lifecycle,
                    "evidence": candidate.get("evidence", {}),
                })
            return

        min_gap = int(candidate.get("min_transition_gap", 0))
        if active is not None and profile["episodes"] - active["episode"] < min_gap:
            self._audit("TRANSITION_DEFERRED", {
                "family": family, "lifecycle_state": lifecycle,
                "episodes_since_active": profile["episodes"] - active["episode"],
                "evidence": candidate.get("evidence", {}),
            })
            return

        audit_candidate = {
            k: v for k, v in candidate.items()
            if k not in {"schema_template", "verified_exemplar", "verified_structural_exemplar", "exemplar"}
        }
        audit_candidate["schema_template_hash"] = template_hash
        if verified_exemplar:
            audit_candidate["verified_exemplar_hash"] = hashlib.sha256(verified_exemplar.encode("utf-8")).hexdigest()
        if verified_structural_exemplar:
            audit_candidate["verified_structural_exemplar_hash"] = hashlib.sha256(
                verified_structural_exemplar.encode("utf-8")
            ).hexdigest()
        self._audit("CANDIDATE_CREATED", audit_candidate)
        admitted, reason = self._gate(candidate)
        profile["version_seq"] += 1
        verified_exemplars = {}
        if verified_exemplar and exemplar_shape_key:
            exemplar_hash = hashlib.sha256(verified_exemplar.encode("utf-8")).hexdigest()
            structural_hash = (
                hashlib.sha256(verified_structural_exemplar.encode("utf-8")).hexdigest()
                if verified_structural_exemplar else None
            )
            verified_exemplars[exemplar_shape_key] = {
                "content": verified_exemplar,
                "hash": exemplar_hash,
                "structural_content": verified_structural_exemplar,
                "structural_hash": structural_hash,
                "shape_key": exemplar_shape_key,
                "verified": True,
            }
        version = {
            "version": profile["version_seq"], "family": family, "rule": candidate["rule"],
            "evidence": candidate.get("evidence", {}),
            "status": lifecycle if admitted else "REJECTED",
            "lifecycle_state": lifecycle if admitted else "REJECTED",
            "gate_reason": reason, "episode": profile["episodes"],
            "decision_label": candidate.get("decision_label"),
            "schema_template": schema_template,
            "schema_template_hash": template_hash,
            "template_metadata": template_metadata,
            "verified_exemplars": verified_exemplars,
        }
        version["hash"] = self._version_hash(version)
        self._append_version(profile, version)
        if admitted:
            if active is not None:
                old_state = active.get("lifecycle_state", active.get("status"))
                active["status"] = "SUPERSEDED"
                self._audit("SUPERSEDED", {
                    "family": family, "old_rule": active["rule"], "new_rule": candidate["rule"],
                    "old_state": old_state, "new_state": lifecycle,
                    "evidence": candidate.get("evidence", {}),
                })
            profile["active_by_family"][family] = version
            self._audit("ADMITTED", {
                "family": family, "rule": candidate["rule"], "lifecycle_state": lifecycle,
                "decision_label": candidate.get("decision_label"),
                "evidence": candidate.get("evidence", {}), "reason": reason,
                "schema_template_hash": template_hash,
                "template_source": template_metadata.get("source"),
                "template_shape_key": template_metadata.get("shape_key"),
                "verified_exemplar_hashes": {
                    key: value["hash"] for key, value in verified_exemplars.items()
                },
            })
        else:
            self._audit("REJECTED", {"family": family, "evidence": candidate.get("evidence", {}), "reason": reason})

    def _gate(self, candidate):
        evidence = candidate.get("evidence", {})
        count = int(evidence.get("count", 0))
        threshold = int(candidate.get("admit_threshold", self.min_evidence))
        if count < threshold:
            return False, f"evidence {count} < {threshold}"
        return True, f"evidence {count} >= {threshold}"

    def active_record(self, family):
        if self.current_key is None:
            return None
        return self.profiles[self.current_key]["active_by_family"].get(family)

    def retrieval_context(self, family=None, operation_shape=None):
        details = {
            "requested_family": family,
            "operation_shape": operation_shape,
            "rule_available": False,
            "persistent_rule_available": False,
            "rule_retrieved": False,
            "schema_template_available": False,
            "schema_template_retrieved": False,
            "persistent_schema_template_retrieved": False,
            "current_instruction_template_available": False,
            "current_instruction_template_retrieved": False,
            "verified_exemplar_available": False,
            "verified_exemplar_retrieved": False,
            "verified_structural_exemplar_available": False,
            "verified_structural_exemplar_retrieved": False,
            "raw_verified_exemplar_retrieved": False,
            "verified_exemplar_suppressed_by_template": False,
            "shape_match": False,
            "memory_provenance": "NONE",
            "primary_memory_class": "NO_MEMORY",
            "applicable_rule_state": None,
            "applicable_decision_label": None,
            "applicable_rule_hash": None,
            "template_hash_at_decision": None,
            "template_source_at_decision": None,
            "prior_active_convention_suppressed": False,
        }
        if self.current_key is None:
            return "", details
        profile = self.profiles[self.current_key]
        if family is None:
            actives = list(profile["active_by_family"].values())
        else:
            active = profile["active_by_family"].get(family)
            actives = [active] if active is not None else []
        if not actives:
            self.retrieval_log.append({
                "episode": self.episode_count, "requested": self.current_key,
                "retrieved": self.current_key, "tokens": 0, **details,
            })
            self.retrieval_log = self.retrieval_log[-self.max_retrieval_log:]
            self._audit("PROFILE_RETRIEVED", {"retrieved": self.current_key, "tokens": 0, **details})
            return "", details

        lines = [f"=== AKILI PROFILE: {profile['display'] or 'unnamed'} | episodes={profile['episodes']} ==="]
        provenance_rank = {
            "NONE": 0, "RULE": 1, "RAW_VERIFIED_EXEMPLAR": 2,
            "VERIFIED_STRUCTURAL_EXEMPLAR": 3, "SCHEMA_TEMPLATE": 4,
        }
        for item in actives:
            state = item.get("lifecycle_state", item["status"])
            lines.append(f"- [{item['family']} | {state}] {item['rule']}")
            details["rule_available"] = True
            details["persistent_rule_available"] = True
            details["rule_retrieved"] = True
            details["applicable_rule_state"] = state if family else details["applicable_rule_state"]
            details["applicable_decision_label"] = item.get("decision_label") if family else details["applicable_decision_label"]
            details["applicable_rule_hash"] = item.get("hash") if family else details["applicable_rule_hash"]
            if provenance_rank["RULE"] > provenance_rank.get(details["memory_provenance"], 0):
                details["memory_provenance"] = "RULE"
                details["primary_memory_class"] = "RULE_ONLY"
            ev = item.get("evidence") or {}
            compact = {k: ev[k] for k in (
                "malicious_count", "benign_count", "recent_labels", "count", "signature"
            ) if k in ev}
            if compact:
                lines.append("  Evidence: " + json.dumps(compact, sort_keys=True))

            exemplars = item.get("verified_exemplars") or {}
            exact_exemplar = exemplars.get(operation_shape) if operation_shape else None
            structural = (exact_exemplar or {}).get("structural_content") if exact_exemplar else None
            details["verified_exemplar_available"] = bool(exact_exemplar)
            details["verified_structural_exemplar_available"] = bool(structural)
            template = item.get("schema_template")
            template_meta = item.get("template_metadata") or {}
            template_matches = bool(template) and (
                operation_shape is None or template_meta.get("shape_key") == operation_shape
            )
            details["schema_template_available"] = bool(template)
            details["shape_match"] = bool(exact_exemplar or template_matches)

            # V3.1.1 precedence: a value-free template outranks any concrete prior output.
            if template_matches:
                lines.append(
                    "  MEMORY TYPE: SCHEMA_TEMPLATE (persistent, deterministic, value-free, not scorer-verified; "
                    "replace every symbolic placeholder with exact values from the CURRENT issue brief)\n"
                    + template.strip()
                )
                details["schema_template_retrieved"] = True
                details["persistent_schema_template_retrieved"] = True
                details["template_hash_at_decision"] = item.get("schema_template_hash")
                details["template_source_at_decision"] = template_meta.get("source")
                details["memory_provenance"] = "SCHEMA_TEMPLATE"
                details["primary_memory_class"] = "PERSISTENT_SCHEMA_TEMPLATE"
                details["verified_exemplar_suppressed_by_template"] = bool(exact_exemplar)
            elif structural:
                lines.append(
                    "  MEMORY TYPE: VERIFIED_STRUCTURAL_EXEMPLAR (derived from a scorer-passing implementation, "
                    "but value-free; replace placeholders with CURRENT issue values)\n"
                    + structural.strip()
                )
                details["verified_exemplar_retrieved"] = True
                details["verified_structural_exemplar_retrieved"] = True
                details["memory_provenance"] = "VERIFIED_STRUCTURAL_EXEMPLAR"
                details["primary_memory_class"] = "VERIFIED_STRUCTURAL_EXEMPLAR"
            elif exact_exemplar:
                lines.append(
                    "  MEMORY TYPE: RAW_VERIFIED_EXEMPLAR (scorer-passing historical output; use only its structure "
                    "and replace all values from the CURRENT issue brief)\n"
                    + exact_exemplar["content"].strip()
                )
                details["verified_exemplar_retrieved"] = True
                details["raw_verified_exemplar_retrieved"] = True
                details["memory_provenance"] = "RAW_VERIFIED_EXEMPLAR"
                details["primary_memory_class"] = "RAW_VERIFIED_EXEMPLAR"
        lines.append("=== END AKILI PROFILE ===")
        block, used = truncate_to_budget("\n".join(lines), self.budget, self.count)
        retrieved_key = profile["key"]
        if retrieved_key != self.current_key:
            self.cross_scope_retrievals += 1
        row = {
            "episode": self.episode_count, "requested": self.current_key,
            "retrieved": retrieved_key, "tokens": used, **details,
        }
        self.retrieval_log.append(row)
        self.retrieval_log = self.retrieval_log[-self.max_retrieval_log:]
        self._audit("PROFILE_RETRIEVED", {"retrieved": retrieved_key, "tokens": used, **details})
        return block, details

    def memory_prompt(self):
        return self.retrieval_context()[0]

    def snapshot(self):
        return {
            "instance_id": self.instance_id, "current_key": self.current_key,
            "profiles": copy.deepcopy(self.profiles), "retrieval_log": copy.deepcopy(self.retrieval_log),
        }

    def report(self):
        live = {"PROVISIONAL", "VERIFIED", "CONFLICTED"}
        admitted_total = sum(1 for p in self.profiles.values() for v in p["versions"]
                             if v["status"] in live | {"SUPERSEDED"})
        superseded = sum(1 for p in self.profiles.values() for v in p["versions"] if v["status"] == "SUPERSEDED")
        active_rules = sum(len(p["active_by_family"]) for p in self.profiles.values())
        lifecycle_counts = {state: 0 for state in ["PROVISIONAL", "VERIFIED", "CONFLICTED", "REJECTED"]}
        status_counts = {state: 0 for state in ["PROVISIONAL", "VERIFIED", "CONFLICTED", "SUPERSEDED", "REJECTED"]}
        schema_templates = 0
        rejected_schema_templates = 0
        verified_exemplars = 0
        for p in self.profiles.values():
            for v in p["versions"]:
                lifecycle = v.get("lifecycle_state", v["status"])
                lifecycle_counts[lifecycle] = lifecycle_counts.get(lifecycle, 0) + 1
                status_counts[v["status"]] = status_counts.get(v["status"], 0) + 1
                if v.get("status") == "REJECTED":
                    rejected_schema_templates += int(bool(v.get("schema_template")))
                else:
                    schema_templates += int(bool(v.get("schema_template")))
                    verified_exemplars += len(v.get("verified_exemplars") or {})
        state_blob = json.dumps(self.snapshot(), sort_keys=True, default=str)
        state_bounded = (
            len(self.profiles) <= self.max_profiles and len(self.retrieval_log) <= self.max_retrieval_log
            and all(len(p["versions"]) <= self.max_versions for p in self.profiles.values())
            and all(len(p["stats"]) <= self.max_stats_keys for p in self.profiles.values())
        )
        return {
            "instance_id": self.instance_id, "profiles": len(self.profiles),
            "stored_memory_chars": len(state_blob), "stored_memory_tokens": self.count(state_blob),
            "active_rules": active_rules, "admitted_total": admitted_total, "superseded": superseded,
            "lifecycle_counts": lifecycle_counts, "status_counts": status_counts,
            "schema_templates": schema_templates,
            "rejected_schema_templates": rejected_schema_templates,
            "verified_exemplars": verified_exemplars,
            "audit_events": len(self.audit), "audit_valid": self.validate_chain(),
            "cross_scope_retrievals": self.cross_scope_retrievals, "state_bounded": state_bounded,
            "current_entity": self.current_key,
        }
