#!/usr/bin/env bash
set -euo pipefail
PYTHON_BIN="${PYTHON_BIN:-python3}"
ROOT="${AKILI_HORIZON_ROOT:-$PWD/akili_horizon_runs}"
mkdir -p "$ROOT"

run_stage () {
  local episodes="$1"
  local name="$2"
  echo "=== $name: $episodes episodes ==="
  "$PYTHON_BIN" mac_horizon_stress.py \
    --episodes "$episodes" \
    --scopes "${AKILI_HORIZON_SCOPES:-100}" \
    --families "${AKILI_HORIZON_FAMILIES:-10}" \
    --output "$ROOT/$name" \
    --checkpoint-every "${AKILI_HORIZON_CHECKPOINT_EVERY:-10000}"
}

run_stage 1000 smoke_1k
run_stage 10000 validation_10k
run_stage 50000 official_50k

if [[ "${AKILI_RUN_500K:-0}" == "1" ]]; then
  run_stage 500000 extended_500k
else
  echo "500k not started. Run: AKILI_RUN_500K=1 ./run_mac_horizon.sh"
fi
