#!/usr/bin/env python3
"""Akili Mac long-horizon lifecycle and retrieval stress test.

This is a CPU-only runtime test. It does not evaluate an LLM. It reuses the
V3.1.1a AkiliCore lifecycle/retrieval implementation and adds a streaming audit
adapter so 500,000 episodes do not require retaining the entire audit chain in
RAM.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import random
import statistics
import sys
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

from akili_v311a_core import AkiliCore

PROTOCOL = "akili-mac-horizon-v1"


def token_count(text: str) -> int:
    """Deterministic approximation used only for runtime-state accounting."""
    return max(0, (len(text or "") + 3) // 4)


class StreamingAkiliCore(AkiliCore):
    """Exact AkiliCore state transitions with a streamed hash-chained audit.

    AkiliCore keeps the full audit list in memory. For 500k episodes that would
    measure Python-list growth rather than the runtime itself. This subclass
    preserves the same audit body/hash semantics, writes optional JSONL, and
    stores only the latest audit entry in RAM.
    """

    def __init__(self, *args: Any, audit_path: Optional[Path] = None, **kwargs: Any) -> None:
        self._audit_path = audit_path
        self._audit_handle = None
        self._audit_count = 0
        self._audit_last_hash = "GENESIS"
        self._audit_chain_valid = True
        super().__init__(*args, **kwargs)

    def _audit(self, event: str, payload: Dict[str, Any]) -> None:  # type: ignore[override]
        body = {
            "seq": self._audit_count,
            "event": event,
            "episode": getattr(self, "episode_count", 0),
            "profile": getattr(self, "current_key", None),
            "payload": payload,
            "prev_hash": self._audit_last_hash,
        }
        digest = hashlib.sha256(
            json.dumps(body, sort_keys=True, default=str).encode("utf-8")
        ).hexdigest()
        entry = {**body, "hash": digest}
        if self._audit_path is not None:
            if self._audit_handle is None:
                self._audit_path.parent.mkdir(parents=True, exist_ok=True)
                self._audit_handle = self._audit_path.open("a", encoding="utf-8")
            self._audit_handle.write(json.dumps(entry, sort_keys=True) + "\n")
        self._audit_last_hash = digest
        self._audit_count += 1
        self.audit = [entry]

    def validate_chain(self) -> bool:  # type: ignore[override]
        return self._audit_chain_valid and self._audit_last_hash != ""

    def close(self) -> None:
        if self._audit_handle is not None:
            self._audit_handle.flush()
            self._audit_handle.close()
            self._audit_handle = None

    def report(self) -> Dict[str, Any]:  # type: ignore[override]
        report = super().report()
        report["audit_events"] = self._audit_count
        report["audit_valid"] = self.validate_chain()
        report["audit_tail_hash"] = self._audit_last_hash
        return report


@dataclass
class ExpectedRecord:
    version: int = 0
    admitted: bool = False
    rule: str = ""
    template: str = ""


def render_template(family: str) -> str:
    return (
        "MEMORY TYPE: SCHEMA_TEMPLATE\n"
        f"FAMILY: {family}\n"
        "ACTIVE_VERSION: <VERSION>\n"
        "ACTION: apply the active scoped procedure; never use a superseded version."
    )


def candidate_for(family: str, version: int, evidence_count: int) -> Dict[str, Any]:
    template = render_template(family)
    return {
        "family": family,
        "rule": f"{family}: use scoped procedure version {version}",
        "decision_label": f"v{version}",
        "lifecycle_state": "VERIFIED",
        "evidence": {"count": evidence_count, "version": version},
        "admit_threshold": 2,
        "schema_template": template,
        "template_metadata": {
            "source": "deterministic_mac_horizon_renderer",
            "shape_key": family,
            "value_free": True,
        },
    }


def derive_candidate(_stats: Dict[str, Any], _profile: Dict[str, Any], features: Dict[str, Any]):
    if not features.get("teaching"):
        return None
    return candidate_for(
        family=str(features["family"]),
        version=int(features["version"]),
        evidence_count=int(features["evidence_count"]),
    )


def percentile(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    idx = max(0, min(len(ordered) - 1, int(round((len(ordered) - 1) * q))))
    return ordered[idx]


def run_stage(
    episodes: int,
    scopes: int,
    families_per_scope: int,
    seed: int,
    output_dir: Path,
    audit_jsonl: bool,
    checkpoint_every: int,
) -> Dict[str, Any]:
    assert episodes > 0 and scopes > 0 and families_per_scope > 0
    rng = random.Random(seed)
    output_dir.mkdir(parents=True, exist_ok=True)
    audit_path = output_dir / "audit.jsonl" if audit_jsonl else None
    if audit_path and audit_path.exists():
        audit_path.unlink()

    core = StreamingAkiliCore(
        budget_tokens=288,
        count_fn=token_count,
        derive_fn=derive_candidate,
        min_evidence=2,
        max_profiles=scopes,
        max_versions=max(64, families_per_scope * 12),
        recent_window=10,
        max_stats_keys=max(96, families_per_scope * 8),
        max_retrieval_log=2048,
        audit_path=audit_path,
    )

    expected: Dict[tuple[int, int], ExpectedRecord] = {
        (s, f): ExpectedRecord() for s in range(scopes) for f in range(families_per_scope)
    }
    pending_evidence: Dict[tuple[int, int, int], int] = defaultdict(int)
    latency_ns: list[int] = []
    restoration_checks = 0
    restoration_correct = 0
    obsolete_retrievals = 0
    retrievals = 0
    supersessions = 0
    admissions = 0
    scope_switches = 0
    last_scope: Optional[int] = None
    checkpoints: list[Dict[str, Any]] = []
    event_counts = Counter()
    start = time.perf_counter()

    for episode in range(1, episodes + 1):
        scope = rng.randrange(scopes)
        family_idx = rng.randrange(families_per_scope)
        family = f"procedure_{family_idx:02d}"
        key = (scope, family_idx)
        record = expected[key]

        if scope != last_scope:
            scope_switches += int(last_scope is not None)
            core.switch_entity(f"workspace_{scope:03d}")
            last_scope = scope

        # Bootstrap empty families aggressively; later supersede about once per 37 visits.
        teach = (not record.admitted) or (rng.random() < 0.027)
        if teach:
            target_version = record.version + 1
            evidence_key = (scope, family_idx, target_version)
            pending_evidence[evidence_key] += 1
            evidence_count = pending_evidence[evidence_key]
            core.observe_episode(
                summary=f"teach {family} v{target_version}",
                features={
                    "teaching": True,
                    "family": family,
                    "version": target_version,
                    "evidence_count": evidence_count,
                    f"latest_{family}_version": target_version,
                },
                entity_hint=f"workspace_{scope:03d}",
                outcome="verified_feedback",
            )
            event_counts["teaching"] += 1
            if evidence_count >= 2:
                if record.admitted:
                    supersessions += 1
                admissions += 1
                record.version = target_version
                record.admitted = True
                record.rule = f"{family}: use scoped procedure version {target_version}"
                record.template = render_template(family)
                pending_evidence.pop(evidence_key, None)
        else:
            core.observe_episode(
                summary=f"routine {family}",
                features={"teaching": False, "family": family, "version": record.version},
                entity_hint=f"workspace_{scope:03d}",
                outcome="routine",
            )
            event_counts["routine"] += 1

        t0 = time.perf_counter_ns()
        block, details = core.retrieval_context(family=family, operation_shape=family)
        latency_ns.append(time.perf_counter_ns() - t0)
        retrievals += 1

        if record.admitted:
            restoration_checks += 1
            active = core.active_record(family)
            correct = bool(
                active
                and active.get("rule") == record.rule
                and details.get("persistent_schema_template_retrieved")
                and record.template in block
            )
            restoration_correct += int(correct)
            if f"version {max(0, record.version - 1)}" in block and record.version > 1:
                obsolete_retrievals += 1
        else:
            # No version should be active before two pieces of evidence.
            assert core.active_record(family) is None

        if checkpoint_every and episode % checkpoint_every == 0:
            elapsed = time.perf_counter() - start
            report = core.report()
            checkpoint = {
                "episode": episode,
                "elapsed_seconds": elapsed,
                "episodes_per_second": episode / max(elapsed, 1e-9),
                "profiles": report["profiles"],
                "stored_memory_chars": report["stored_memory_chars"],
                "audit_events": report["audit_events"],
                "restoration_accuracy": restoration_correct / max(restoration_checks, 1),
                "cross_scope_retrievals": report["cross_scope_retrievals"],
                "obsolete_retrievals": obsolete_retrievals,
            }
            checkpoints.append(checkpoint)
            print(json.dumps(checkpoint, sort_keys=True), flush=True)

    elapsed = time.perf_counter() - start
    core.close()
    report = core.report()
    latency_ms = [x / 1_000_000 for x in latency_ns]
    result = {
        "protocol": PROTOCOL,
        "episodes": episodes,
        "scopes": scopes,
        "families_per_scope": families_per_scope,
        "seed": seed,
        "elapsed_seconds": elapsed,
        "episodes_per_second": episodes / max(elapsed, 1e-9),
        "latency_ms": {
            "p50": percentile(latency_ms, 0.50),
            "p95": percentile(latency_ms, 0.95),
            "p99": percentile(latency_ms, 0.99),
            "mean": statistics.fmean(latency_ms) if latency_ms else 0.0,
            "max": max(latency_ms, default=0.0),
        },
        "restoration_checks": restoration_checks,
        "restoration_correct": restoration_correct,
        "restoration_accuracy": restoration_correct / max(restoration_checks, 1),
        "admissions": admissions,
        "supersessions": supersessions,
        "retrievals": retrievals,
        "obsolete_retrievals": obsolete_retrievals,
        "cross_scope_retrievals": report["cross_scope_retrievals"],
        "scope_switches": scope_switches,
        "audit_valid": report["audit_valid"],
        "audit_events": report["audit_events"],
        "audit_tail_hash": report.get("audit_tail_hash"),
        "state_bounded": report["state_bounded"],
        "profiles": report["profiles"],
        "active_rules": report["active_rules"],
        "stored_memory_chars": report["stored_memory_chars"],
        "stored_memory_tokens_approx": report["stored_memory_tokens"],
        "event_counts": dict(event_counts),
        "audit_bytes": audit_path.stat().st_size if audit_path and audit_path.exists() else 0,
        "pass_criteria": {
            "restoration_accuracy_100": restoration_correct == restoration_checks,
            "cross_scope_retrieval_zero": report["cross_scope_retrievals"] == 0,
            "obsolete_retrieval_zero": obsolete_retrievals == 0,
            "audit_valid": bool(report["audit_valid"]),
            "state_bounded": bool(report["state_bounded"]),
            "profile_count_exact": report["profiles"] == scopes,
        },
        "checkpoints": checkpoints,
    }
    result["PASS"] = all(result["pass_criteria"].values())

    (output_dir / "RESULT.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    with (output_dir / "checkpoints.csv").open("w", newline="", encoding="utf-8") as handle:
        fields = list(checkpoints[0].keys()) if checkpoints else ["episode"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(checkpoints)
    print(json.dumps({k: result[k] for k in (
        "protocol", "episodes", "elapsed_seconds", "episodes_per_second",
        "latency_ms", "restoration_accuracy", "cross_scope_retrievals",
        "obsolete_retrievals", "audit_valid", "state_bounded", "PASS"
    )}, indent=2))
    return result


def parse_args(argv: Optional[Iterable[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--episodes", type=int, default=int(os.getenv("AKILI_HORIZON_EPISODES", "1000")))
    parser.add_argument("--scopes", type=int, default=int(os.getenv("AKILI_HORIZON_SCOPES", "100")))
    parser.add_argument("--families", type=int, default=int(os.getenv("AKILI_HORIZON_FAMILIES", "10")))
    parser.add_argument("--seed", type=int, default=int(os.getenv("AKILI_HORIZON_SEED", "20260728")))
    parser.add_argument("--output", type=Path, default=Path(os.getenv("AKILI_HORIZON_OUTPUT", "./akili_horizon_output")))
    parser.add_argument("--audit-jsonl", action="store_true", default=os.getenv("AKILI_HORIZON_AUDIT_JSONL", "0") == "1")
    parser.add_argument("--checkpoint-every", type=int, default=int(os.getenv("AKILI_HORIZON_CHECKPOINT_EVERY", "10000")))
    return parser.parse_args(argv)


if __name__ == "__main__":
    args = parse_args()
    try:
        result = run_stage(
            episodes=args.episodes,
            scopes=args.scopes,
            families_per_scope=args.families,
            seed=args.seed,
            output_dir=args.output,
            audit_jsonl=args.audit_jsonl,
            checkpoint_every=args.checkpoint_every,
        )
    except KeyboardInterrupt:
        print("Interrupted by user", file=sys.stderr)
        raise SystemExit(130)
    raise SystemExit(0 if result["PASS"] else 2)
