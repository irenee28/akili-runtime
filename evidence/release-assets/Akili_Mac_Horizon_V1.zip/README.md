# Akili Mac Horizon V1

CPU-only long-horizon lifecycle, isolation and retrieval stress test using the V3.1.1a `AkiliCore` implementation with a streamed audit adapter.

## Requirements

- macOS or Linux
- Python 3.10+
- No GPU and no third-party Python package

## Run in stages

```bash
cd mac_horizon
python3 mac_horizon_stress.py --episodes 1000 --output ./runs/smoke_1k
python3 mac_horizon_stress.py --episodes 10000 --output ./runs/validation_10k
python3 mac_horizon_stress.py --episodes 50000 --output ./runs/official_50k
python3 mac_horizon_stress.py --episodes 500000 --output ./runs/extended_500k
```

Or:

```bash
./run_mac_horizon.sh
AKILI_RUN_500K=1 ./run_mac_horizon.sh
```

The 500k run should start only after the first three stages pass.

## Mandatory pass criteria

- restoration accuracy = 100%
- cross-scope retrieval = 0
- obsolete-version retrieval = 0
- audit chain remains valid
- state remains within configured bounds
- exactly 100 scopes are created

Each output directory contains `RESULT.json` and `checkpoints.csv`. Add `--audit-jsonl` only when you want the full audit stream written to disk; it substantially increases disk I/O and output size.
