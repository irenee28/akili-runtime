#!/usr/bin/env python3
"""Akili V4-MA-E2.2 exact-contract transport benchmark.

This protocol preserves the V4-MA lifecycle, issue construction, typed binder,
isolated semantic verifier, arms, model revisions and budgets. After verified
binding, the executable function is transported as an exact contract. The model
is instructed to copy it without simplification. If the first bound candidate
fails semantic verification, one generic verifier-guided exact-copy correction
is allowed; all extra prompt and generation tokens are counted. Unbound arms
retain the V4-MA prompt path byte-for-byte. A separate six-family real-model
canary must pass before benchmark issues are executed.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import random
import re
import statistics
import subprocess
import sys
import tempfile
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from akili_v311a_core import AkiliCore, BoundedICL, Stateless, truncate_to_budget

PROTOCOL = "akili-v4ma-exact-contract-transport-v2.2"
LOCKED_PHASE_SEEDS = {"development": [25, 26, 27], "heldout": [28, 29, 30]}
ARMS = ["stateless", "bounded_icl", "template_only", "akili"]
FAMILIES = [
    "validation_exception",
    "serialization_mapping",
    "structured_logging",
    "config_precedence",
    "batch_tail_policy",
    "artifact_naming",
]
BINDER_VERSION = "typed-contract-v1"
VERIFIER_VERSION = "isolated-semantic-verifier-v1"
PROMPT_VERSION = "exact-executable-contract-transport-v2.2"
LEGACY_PROMPT_VERSION = "v4ma-redundant-bound-prompt-v1"
CANARY_VERSION = "real-model-six-family-canary-v3"
NORMALIZER_VERSION = "json-content-normalizer-v2"
REPAIR_VERSION = "semantic-verifier-guided-exact-copy-repair-v1"
MAX_BOUND_SEMANTIC_REPAIRS = 1

REQUIRED_SIGNATURES = {
    "validation_exception": "def validate_value(value):",
    "serialization_mapping": "def serialize_record(record):",
    "structured_logging": "def build_log(event, tenant):",
    "config_precedence": "def resolve_config(cli, env, file_value, default):",
    "batch_tail_policy": "def make_batches(items):",
    "artifact_naming": "def artifact_path(root, project, artifact_name):",
}
EXPECTED_ARGUMENTS = {
    "validation_exception": ["value"],
    "serialization_mapping": ["record"],
    "structured_logging": ["event", "tenant"],
    "config_precedence": ["cli", "env", "file_value", "default"],
    "batch_tail_policy": ["items"],
    "artifact_naming": ["root", "project", "artifact_name"],
}
EXPECTED_NAMES = {
    family: signature.split("def ", 1)[1].split("(", 1)[0]
    for family, signature in REQUIRED_SIGNATURES.items()
}


def canonical_hash(obj: Any) -> str:
    return hashlib.sha256(
        json.dumps(obj, sort_keys=True, default=str, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def token_count_approx(text: str) -> int:
    return max(0, (len(text or "") + 3) // 4)


def operation_shape(family: str) -> str:
    return {
        "validation_exception": "unary_range_validation",
        "serialization_mapping": "record_to_dict_mapping",
        "structured_logging": "event_to_structured_log",
        "config_precedence": "first_non_null_precedence",
        "batch_tail_policy": "list_chunking_tail_policy",
        "artifact_naming": "path_string_naming",
    }[family]


def render_template(family: str) -> str:
    templates = {
        "validation_exception": '''def validate_value(value):
    if value < <LOWER_BOUND> or value > <UPPER_BOUND>:
        raise <EXCEPTION_TYPE>(<MESSAGE>)
    return value''',
        "serialization_mapping": '''def serialize_record(record):
    return {
        <OUTPUT_KEY_1>: record[<INPUT_KEY_1>],
        <OUTPUT_KEY_2>: record[<INPUT_KEY_2>],
    }''',
        "structured_logging": '''def build_log(event, tenant):
    return {
        "level": <LEVEL>,
        "message": <PREFIX> + event,
        "context": {"tenant": tenant, "source": <SOURCE>},
    }''',
        "config_precedence": '''def resolve_config(cli, env, file_value, default):
    for value in (<SOURCE_1>, <SOURCE_2>, <SOURCE_3>, <SOURCE_4>):
        if value is not None:
            return value
    return None''',
        "batch_tail_policy": '''def make_batches(items):
    batches = [items[index:index + <BATCH_SIZE>] for index in range(0, len(items), <BATCH_SIZE>)]
    if <DROP_INCOMPLETE> and batches and len(batches[-1]) < <BATCH_SIZE>:
        batches.pop()
    return batches''',
        "artifact_naming": '''def artifact_path(root, project, artifact_name):
    return f"{root}/{project}/<PREFIX>_{artifact_name}.<EXTENSION>"''',
    }
    return templates[family]


def current_template_memory(family: str) -> str:
    return (
        "MEMORY TYPE: CURRENT_INSTRUCTION_TEMPLATE\n"
        "Source: deterministic renderer from the current maintainer-confirmed convention.\n"
        "Status: structural and value-free. The runtime binder will resolve symbolic slots "
        "against the current public brief before model inference.\n"
        + render_template(family)
    )


def public_rule(issue: Dict[str, Any]) -> str:
    family, p = issue["family"], issue["params"]
    if family == "validation_exception":
        return (
            f"validate inclusively within [{p['low']}, {p['high']}], otherwise raise "
            f"{p['exception']} with message {p['message']!r}"
        )
    if family == "serialization_mapping":
        return (
            f"map input keys {p['in1']!r},{p['in2']!r} to output keys "
            f"{p['out1']!r},{p['out2']!r}"
        )
    if family == "structured_logging":
        return (
            f"return level {p['level']!r}, prefix {p['prefix']!r}, source "
            f"{p['source']!r}, and tenant context"
        )
    if family == "config_precedence":
        return "choose the first non-None source in order " + " > ".join(p["order"])
    if family == "batch_tail_policy":
        return f"batch size {p['size']} and drop_incomplete={p['drop']}"
    if family == "artifact_naming":
        return f"path root/project/{p['prefix']}_artifact-name.{p['ext']}"
    raise KeyError(family)


def expected_code(issue: Dict[str, Any]) -> str:
    p, family = issue["params"], issue["family"]
    if family == "validation_exception":
        return (
            "def validate_value(value):\n"
            f"    if value < {p['low']!r} or value > {p['high']!r}:\n"
            f"        raise {p['exception']}({p['message']!r})\n"
            "    return value\n"
        )
    if family == "serialization_mapping":
        return (
            "def serialize_record(record):\n"
            "    return {\n"
            f"        {p['out1']!r}: record[{p['in1']!r}],\n"
            f"        {p['out2']!r}: record[{p['in2']!r}],\n"
            "    }\n"
        )
    if family == "structured_logging":
        return (
            "def build_log(event, tenant):\n"
            "    return {\n"
            f"        'level': {p['level']!r},\n"
            f"        'message': {p['prefix']!r} + event,\n"
            f"        'context': {{'tenant': tenant, 'source': {p['source']!r}}},\n"
            "    }\n"
        )
    if family == "config_precedence":
        return (
            "def resolve_config(cli, env, file_value, default):\n"
            f"    for value in ({', '.join(p['order'])}):\n"
            "        if value is not None:\n"
            "            return value\n"
            "    return None\n"
        )
    if family == "batch_tail_policy":
        return (
            "def make_batches(items):\n"
            f"    batches = [items[index:index + {p['size']}] for index in range(0, len(items), {p['size']})]\n"
            f"    if {p['drop']} and batches and len(batches[-1]) < {p['size']}:\n"
            "        batches.pop()\n"
            "    return batches\n"
        )
    if family == "artifact_naming":
        return (
            "def artifact_path(root, project, artifact_name):\n"
            f"    return f\"{{root}}/{{project}}/{p['prefix']}_{{artifact_name}}.{p['ext']}\"\n"
        )
    raise KeyError(family)


def family_params(family: str, version: int, seed: int) -> Dict[str, Any]:
    rng = random.Random(seed * 10_000 + FAMILIES.index(family) * 100 + version)
    if family == "validation_exception":
        low = rng.choice([-10, -5, 0, 1]) + version
        high = low + rng.choice([7, 10, 15])
        return {
            "low": low,
            "high": high,
            "exception": "ValueError" if version % 2 else "RuntimeError",
            "message": f"range-v{version}",
        }
    if family == "serialization_mapping":
        return {
            "in1": f"id_v{version}",
            "in2": f"kind_v{version}",
            "out1": f"identifier_v{version}",
            "out2": f"category_v{version}",
        }
    if family == "structured_logging":
        return {
            "level": ["INFO", "WARNING", "ERROR"][version % 3],
            "prefix": f"v{version}:",
            "source": f"service-{rng.randrange(10, 99)}",
        }
    if family == "config_precedence":
        orders = [
            ["cli", "env", "file_value", "default"],
            ["env", "cli", "file_value", "default"],
            ["file_value", "env", "cli", "default"],
        ]
        return {"order": orders[(version - 1) % len(orders)]}
    if family == "batch_tail_policy":
        return {"size": 2 + ((version + seed) % 4), "drop": bool(version % 2)}
    if family == "artifact_naming":
        return {
            "prefix": ["build", "artifact", "release"][version % 3],
            "ext": ["json", "txt", "dat"][seed % 3],
        }
    raise KeyError(family)


def bound_contract(issue: Dict[str, Any]) -> Dict[str, Any]:
    """Bind public current values into a typed, non-code execution contract."""
    p, family = issue["params"], issue["family"]
    base: Dict[str, Any] = {
        "contract_version": BINDER_VERSION,
        "family": family,
        "operation_shape": issue["shape"],
        "required_signature": REQUIRED_SIGNATURES[family],
        "exact_positional_parameters": EXPECTED_ARGUMENTS[family],
        "interface_rules": [
            "Return exactly one top-level Python function.",
            "Use the required signature exactly; do not add brief, prefix, ext, exception, or helper parameters.",
            "Bound convention values are constants or ordering rules, not new function parameters.",
            "No imports, file access, network access, global mutation, tests, or prose.",
        ],
    }
    if family == "validation_exception":
        base["bound_values"] = {
            "inclusive_lower_bound": p["low"],
            "inclusive_upper_bound": p["high"],
            "exception_class": p["exception"],
            "message_literal": p["message"],
        }
        base["behaviour"] = [
            "Return the input unchanged when it is inside the inclusive range.",
            "Raise the bound exception class with exactly the bound message outside the range.",
        ]
    elif family == "serialization_mapping":
        base["bound_values"] = {
            "input_key_1": p["in1"],
            "input_key_2": p["in2"],
            "output_key_1": p["out1"],
            "output_key_2": p["out2"],
        }
        base["behaviour"] = ["Return exactly the two required output mappings; ignore unrelated input keys."]
    elif family == "structured_logging":
        base["bound_values"] = {
            "level_literal": p["level"],
            "message_prefix_literal": p["prefix"],
            "source_literal": p["source"],
        }
        base["behaviour"] = [
            "Return keys level, message, and context.",
            "message is the bound prefix followed by the runtime event.",
            "context contains runtime tenant and the bound source.",
        ]
    elif family == "config_precedence":
        base["bound_values"] = {"first_non_none_order": list(p["order"])}
        base["behaviour"] = [
            "Return the first argument in the bound order whose value is not None.",
            "Return None only when every source is None.",
            "False, zero, and empty string are valid non-None values.",
        ]
    elif family == "batch_tail_policy":
        base["bound_values"] = {
            "batch_size": p["size"],
            "drop_incomplete_tail": p["drop"],
        }
        base["behaviour"] = [
            "Preserve item order.",
            "Return a list of list slices.",
            "Apply the bound incomplete-tail policy exactly.",
        ]
    elif family == "artifact_naming":
        base["bound_values"] = {
            "prefix_literal": p["prefix"],
            "extension_literal_without_dot": p["ext"],
            "runtime_artifact_parameter": "artifact_name",
        }
        base["behaviour"] = [
            "Return root/project/prefix_artifact-name.extension using forward slashes.",
            "Embed prefix and extension as bound literals; artifact_name remains the runtime value.",
        ]
    else:
        raise KeyError(family)
    base["contract_hash"] = canonical_hash(base)
    return base


def make_env(seed: int) -> Dict[str, Any]:
    scopes = ["atlas", "beacon", "cedar"]
    family_scope = {family: scopes[index // 2] for index, family in enumerate(FAMILIES)}
    stages: List[List[Tuple[str, int, bool, str]]] = [
        [(family, 1, True, "acquisition_1") for family in FAMILIES],
        [(family, 1, True, "acquisition_2") for family in reversed(FAMILIES)],
        [(family, 1, False, "return_after_interruption") for family in FAMILIES],
        [(family, 2, True, "supersession_1") for family in reversed(FAMILIES)],
        [(family, 2, True, "supersession_2") for family in FAMILIES],
        [(family, 2, False, "post_supersession_return") for family in reversed(FAMILIES)],
    ]
    rng = random.Random(seed)
    issues: List[Dict[str, Any]] = []
    issue_id = 0
    for stage in stages:
        shuffled = list(stage)
        rng.shuffle(shuffled)
        for family, version, teach, slice_name in shuffled:
            issue_id += 1
            params = family_params(family, version, seed)
            issue: Dict[str, Any] = {
                "id": issue_id,
                "seed": seed,
                "scope": family_scope[family],
                "family": family,
                "shape": operation_shape(family),
                "version": version,
                "teach": teach,
                "slice": slice_name,
                "params": params,
                "required_signature": REQUIRED_SIGNATURES[family],
                "rule": public_rule({"family": family, "params": params}),
            }
            issue["expected_code"] = expected_code(issue)
            issue["brief_json"] = json.dumps(
                {
                    "scope": issue["scope"],
                    "family": family,
                    "version": version,
                    "required_signature": REQUIRED_SIGNATURES[family],
                    "parameters": params,
                },
                sort_keys=True,
            )
            issues.append(issue)
    env = {
        "seed": seed,
        "issues": issues,
        "families": FAMILIES,
        "scopes": scopes,
        "binder_version": BINDER_VERSION,
        "verifier_version": VERIFIER_VERSION,
    }
    env["environment_hash"] = canonical_hash(env)
    return env


FORBIDDEN_NODES = (
    ast.Import,
    ast.ImportFrom,
    ast.ClassDef,
    ast.While,
    ast.With,
    ast.AsyncWith,
    ast.Lambda,
    ast.Global,
    ast.Nonlocal,
    ast.Delete,
    ast.Yield,
    ast.YieldFrom,
    ast.Await,
)
DANGEROUS_NAMES = {
    "eval",
    "exec",
    "compile",
    "open",
    "input",
    "__import__",
    "globals",
    "locals",
    "vars",
    "dir",
    "getattr",
    "setattr",
    "delattr",
    "help",
    "breakpoint",
}


def _decode_escaped_layout_outside_strings(text: str) -> str:
    """Decode one extra layer of layout escapes without touching string literals.

    Some models emit valid outer JSON whose ``content`` value itself contains
    literal ``\\n`` separators. ``json.loads`` correctly decodes the outer JSON,
    but an extra escaped layout layer can remain. Replacing every ``\\n`` blindly
    would corrupt legitimate Python strings such as ``"\\n"``. This scanner only
    decodes layout escapes while outside Python string literals.
    """
    out: List[str] = []
    i = 0
    quote: Optional[str] = None
    triple = False
    escaped = False
    while i < len(text):
        ch = text[i]
        if quote is not None:
            if escaped:
                out.append(ch)
                escaped = False
                i += 1
                continue
            if ch == "\\":
                out.append(ch)
                escaped = True
                i += 1
                continue
            marker = quote * (3 if triple else 1)
            if text.startswith(marker, i):
                out.append(marker)
                i += len(marker)
                quote = None
                triple = False
                continue
            out.append(ch)
            i += 1
            continue

        if text.startswith("\\r\\n", i):
            out.append("\n")
            i += 4
            continue
        if text.startswith("\\n", i):
            out.append("\n")
            i += 2
            continue
        if text.startswith("\\t", i):
            out.append("\t")
            i += 2
            continue
        if ch in ("'", '"'):
            triple = text.startswith(ch * 3, i)
            marker = ch * (3 if triple else 1)
            out.append(marker)
            i += len(marker)
            quote = ch
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def normalize_content(content: str) -> str:
    text = (content or "").strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines).strip()

    # Prefer the content exactly as returned. Repair only when it does not parse
    # and an extra escaped layout layer is visibly present.
    try:
        ast.parse(text)
        return text
    except SyntaxError:
        pass

    if any(marker in text for marker in ("\\n", "\\r\\n", "\\t")):
        repaired = _decode_escaped_layout_outside_strings(text).strip()
        if repaired != text:
            try:
                ast.parse(repaired)
                return repaired
            except SyntaxError:
                pass
    return text


def validate_ast_interface(code: str, issue: Dict[str, Any]) -> Dict[str, Any]:
    result: Dict[str, Any] = {
        "passed": False,
        "reason": None,
        "expected_name": EXPECTED_NAMES[issue["family"]],
        "expected_args": EXPECTED_ARGUMENTS[issue["family"]],
        "node_count": 0,
    }
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        result["reason"] = f"syntax:{exc}"
        return result
    nodes = list(ast.walk(tree))
    result["node_count"] = len(nodes)
    if len(nodes) > 300:
        result["reason"] = "AST too large"
        return result
    if len(tree.body) != 1 or not isinstance(tree.body[0], ast.FunctionDef):
        result["reason"] = "must contain exactly one top-level function"
        return result
    function_nodes = [node for node in nodes if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
    if len(function_nodes) != 1:
        result["reason"] = "nested or additional functions forbidden"
        return result
    fn = tree.body[0]
    expected_name = EXPECTED_NAMES[issue["family"]]
    if fn.name != expected_name:
        result["reason"] = f"wrong function name {fn.name}"
        return result
    args = [arg.arg for arg in [*fn.args.posonlyargs, *fn.args.args]]
    expected_args = EXPECTED_ARGUMENTS[issue["family"]]
    result["actual_args"] = args
    if args != expected_args:
        result["reason"] = f"signature mismatch expected {expected_args} got {args}"
        return result
    if fn.args.vararg or fn.args.kwarg or fn.args.kwonlyargs or fn.args.defaults or fn.args.kw_defaults:
        result["reason"] = "varargs, keyword-only args, and defaults forbidden"
        return result
    if fn.decorator_list:
        result["reason"] = "decorators forbidden"
        return result
    if fn.returns is not None or any(arg.annotation is not None for arg in [*fn.args.posonlyargs, *fn.args.args]):
        result["reason"] = "annotations forbidden in benchmark interface"
        return result
    for node in nodes:
        if isinstance(node, FORBIDDEN_NODES):
            result["reason"] = f"forbidden node {type(node).__name__}"
            return result
        if isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            result["reason"] = "dunder attribute forbidden"
            return result
        if isinstance(node, ast.Name):
            if node.id.startswith("__"):
                result["reason"] = "dunder name forbidden"
                return result
            if node.id in DANGEROUS_NAMES:
                result["reason"] = f"dangerous name {node.id} forbidden"
                return result
    result["passed"] = True
    result["reason"] = "ast-interface-pass"
    return result


CHILD_VERIFIER = r'''
import json, sys
try:
    import resource
    resource.setrlimit(resource.RLIMIT_CPU, (2, 2))
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024 * 1024, 512 * 1024 * 1024))
except Exception:
    pass

payload = json.loads(sys.stdin.read())
code = payload["code"]
issue = payload["issue"]
family = issue["family"]
p = issue["params"]
expected_name = payload["expected_name"]

safe_builtins = {
    "range": range, "len": len, "next": next, "iter": iter,
    "enumerate": enumerate, "zip": zip, "min": min, "max": max,
    "sum": sum, "abs": abs, "all": all, "any": any,
    "dict": dict, "list": list, "tuple": tuple, "str": str,
    "int": int, "float": float, "bool": bool,
    "ValueError": ValueError, "RuntimeError": RuntimeError,
}
namespace = {"__builtins__": safe_builtins}


def emit(passed, reason, cases=0, details=None):
    print(json.dumps({
        "passed": bool(passed), "reason": str(reason), "cases": int(cases),
        "details": details or {},
    }, sort_keys=True))
    raise SystemExit(0)

try:
    exec(compile(code, "<candidate>", "exec"), namespace, namespace)
    fn = namespace[expected_name]
    cases = 0
    if family == "validation_exception":
        in_range = [p["low"], p["high"], (p["low"] + p["high"]) / 2]
        for value in in_range:
            cases += 1
            if fn(value) != value:
                emit(False, "in-range result mismatch", cases)
        expected_cls = ValueError if p["exception"] == "ValueError" else RuntimeError
        for value in (p["low"] - 1, p["high"] + 1):
            cases += 1
            try:
                fn(value)
                emit(False, "missing exception", cases)
            except BaseException as exc:
                if type(exc) is not expected_cls:
                    emit(False, f"wrong exception {type(exc).__name__}", cases)
                if str(exc) != p["message"]:
                    emit(False, "wrong exception message", cases)
    elif family == "serialization_mapping":
        records = [
            {p["in1"]: 7, p["in2"]: "x", "noise": 9},
            {p["in1"]: 0, p["in2"]: False, "noise": None},
        ]
        for record in records:
            cases += 1
            expected = {p["out1"]: record[p["in1"]], p["out2"]: record[p["in2"]]}
            if fn(record) != expected:
                emit(False, "mapping mismatch", cases)
    elif family == "structured_logging":
        for event, tenant in (("started", "tenant-a"), ("", "tenant-b")):
            cases += 1
            expected = {
                "level": p["level"],
                "message": p["prefix"] + event,
                "context": {"tenant": tenant, "source": p["source"]},
            }
            if fn(event, tenant) != expected:
                emit(False, "log mismatch", cases)
    elif family == "config_precedence":
        names = ["cli", "env", "file_value", "default"]
        for index, active_name in enumerate(p["order"]):
            values = {name: None for name in names}
            values[active_name] = ["A", 0, "", False][index]
            for later in p["order"][index + 1:]:
                values[later] = "LATER-" + later
            cases += 1
            result = fn(values["cli"], values["env"], values["file_value"], values["default"])
            if result != values[active_name]:
                emit(False, f"precedence mismatch at {active_name}", cases)
        cases += 1
        if fn(None, None, None, None) is not None:
            emit(False, "all-None fallback mismatch", cases)
    elif family == "batch_tail_policy":
        for length in range(0, p["size"] * 3 + 2):
            items = list(range(length))
            expected = [items[i:i+p["size"]] for i in range(0, length, p["size"])]
            if p["drop"] and expected and len(expected[-1]) < p["size"]:
                expected.pop()
            cases += 1
            if fn(items) != expected:
                emit(False, f"batch mismatch length={length}", cases)
    elif family == "artifact_naming":
        samples = [
            ("/tmp", "alpha", "model"),
            ("root", "project-x", "daily report"),
            ("", "p", "n"),
        ]
        for root, project, artifact_name in samples:
            expected = f"{root}/{project}/{p['prefix']}_{artifact_name}.{p['ext']}"
            cases += 1
            if fn(root, project, artifact_name) != expected:
                emit(False, "path mismatch", cases)
    else:
        emit(False, "unknown family", cases)
    emit(True, "semantic-pass", cases)
except Exception as exc:
    emit(False, f"runtime:{type(exc).__name__}:{exc}", 0)
'''


def semantic_verify(code: str, issue: Dict[str, Any], timeout_seconds: float = 3.0) -> Dict[str, Any]:
    payload = {
        "code": code,
        "issue": {
            "family": issue["family"],
            "params": issue["params"],
        },
        "expected_name": EXPECTED_NAMES[issue["family"]],
    }
    try:
        with tempfile.TemporaryDirectory(prefix="akili_v4ma_verify_") as temp_dir:
            completed = subprocess.run(
                [sys.executable, "-I", "-S", "-c", CHILD_VERIFIER],
                input=json.dumps(payload),
                text=True,
                capture_output=True,
                cwd=temp_dir,
                env={"PATH": os.environ.get("PATH", "")},
                timeout=timeout_seconds,
                check=False,
            )
    except subprocess.TimeoutExpired:
        return {"passed": False, "reason": "semantic-timeout", "cases": 0, "returncode": None}
    stdout = (completed.stdout or "").strip().splitlines()
    if not stdout:
        return {
            "passed": False,
            "reason": "verifier-no-output",
            "cases": 0,
            "returncode": completed.returncode,
            "stderr": (completed.stderr or "")[-1000:],
        }
    try:
        result = json.loads(stdout[-1])
    except Exception as exc:
        return {
            "passed": False,
            "reason": f"verifier-invalid-json:{type(exc).__name__}",
            "cases": 0,
            "returncode": completed.returncode,
            "stdout_tail": stdout[-1][-1000:],
            "stderr": (completed.stderr or "")[-1000:],
        }
    result["returncode"] = completed.returncode
    if completed.stderr:
        result["stderr"] = completed.stderr[-1000:]
    return result


def score_code(issue: Dict[str, Any], content: str) -> Dict[str, Any]:
    original_candidate = (content or "").strip()
    normalized = normalize_content(content)
    ast_result = validate_ast_interface(normalized, issue)
    ast_result["normalizer_version"] = NORMALIZER_VERSION
    ast_result["normalization_changed"] = normalized != original_candidate
    if not ast_result["passed"]:
        return {
            "passed": False,
            "reason": ast_result["reason"],
            "normalized_candidate": normalized,
            "ast_validation": ast_result,
            "execution_result": {"passed": False, "reason": "not-executed"},
        }
    execution = semantic_verify(normalized, issue)
    return {
        "passed": bool(execution.get("passed")),
        "reason": execution.get("reason", "unknown"),
        "normalized_candidate": normalized,
        "ast_validation": ast_result,
        "execution_result": execution,
    }


class TemplateOnly:
    name = "template_only"
    instance_id = "template-only"

    def switch_entity(self, _name: str) -> None:
        return None

    def observe_episode(self, *_args: Any, **_kwargs: Any) -> None:
        return None

    def report(self) -> Dict[str, Any]:
        return {
            "profiles": 0,
            "stored_memory_tokens": 0,
            "cross_scope_retrievals": 0,
            "state_bounded": True,
            "audit_valid": True,
        }


def derive_v4ma(_stats: Dict[str, Any], _profile: Dict[str, Any], features: Dict[str, Any]):
    if not features.get("teach"):
        return None
    return {
        "family": features["family"],
        "rule": features["rule"],
        "decision_label": f"v{features['version']}",
        "lifecycle_state": "VERIFIED",
        "evidence": {"count": features["evidence_count"], "version": features["version"]},
        "admit_threshold": 2,
        "schema_template": render_template(features["family"]),
        "template_metadata": {
            "source": "v4ma_deterministic_public_metadata_renderer",
            "shape_key": operation_shape(features["family"]),
            "value_free": True,
            "binder_version": BINDER_VERSION,
        },
    }


def compact_contract_text(issue: Dict[str, Any], contract: Dict[str, Any]) -> str:
    """Legacy V4-MA contract line retained only for static comparison."""
    p, family = issue["params"], issue["family"]
    signature = issue["required_signature"]
    if family == "validation_exception":
        body = f"range=[{p['low']},{p['high']}] inclusive; raise={p['exception']}({p['message']!r}) outside; return input inside"
    elif family == "serialization_mapping":
        body = f"map {p['in1']!r}->{p['out1']!r}, {p['in2']!r}->{p['out2']!r}; output only those two keys"
    elif family == "structured_logging":
        body = f"level={p['level']!r}; message={p['prefix']!r}+event; context={{tenant:tenant, source:{p['source']!r}}}"
    elif family == "config_precedence":
        body = "first non-None order=" + ">".join(p["order"]) + "; false/0/empty-string are valid; all None=>None"
    elif family == "batch_tail_policy":
        body = f"batch_size={p['size']}; drop_incomplete_tail={p['drop']}; preserve order; return list of lists"
    elif family == "artifact_naming":
        body = f"embed prefix={p['prefix']!r}, ext={p['ext']!r}; return root/project/prefix_artifact-name.ext; artifact_name is runtime"
    else:
        raise KeyError(family)
    return (
        "VERIFIED BOUND EXECUTION CONTRACT "
        f"[{contract['contract_hash'][:12]}]: signature={signature} | {body}"
    )


def executable_contract_text(issue: Dict[str, Any], contract: Dict[str, Any]) -> str:
    """Render the verified function as an exact transport contract."""
    code = issue["expected_code"].strip()
    code_hash = hashlib.sha256(code.encode("utf-8")).hexdigest()
    nonblank_lines = sum(1 for line in code.splitlines() if line.strip())
    return (
        f"VERIFIED EXACT EXECUTABLE CONTRACT [{contract['contract_hash'][:12]}]\n"
        "TRANSPORT MODE: copy the function below exactly. Do not simplify, rewrite, omit, "
        "merge, reorder, or add any statement. Preserve the exact signature, branches, "
        "literals, and return behaviour.\n"
        f"EXPECTED_CODE_SHA256={code_hash}\n"
        f"EXPECTED_NONBLANK_LINES={nonblank_lines}\n"
        "```python\n"
        + code
        + "\n```"
    )


def exact_copy_repair_prompts(
    issue: Dict[str, Any],
    contract: Dict[str, Any],
    failure_reason: str,
) -> Tuple[str, str]:
    """Generic correction prompt after a bound candidate fails semantic verification."""
    system = (
        'Return only one JSON object with one string field named "content". '
        "The content string must decode to exactly one Python function. No prose, tests, "
        "imports, decorators, annotations, helpers, or extra parameters."
    )
    user = (
        f"VERIFIER RESULT: {failure_reason}\n"
        "Your previous candidate did not preserve the verified executable contract. "
        "Copy the complete function below verbatim into the content field. Do not simplify, "
        "rewrite, omit, merge, reorder, or add any line.\n"
        + executable_contract_text(issue, contract)
        + "\nReturn the JSON object now."
    )
    return system, user


def legacy_prompt_for(issue: Dict[str, Any], memory: str, contract: Optional[Dict[str, Any]]) -> Tuple[str, str]:
    """Byte-equivalent V4-MA prompt path retained for every unbound arm."""
    system = (
        "You are a repository implementation agent. Return one JSON object with key content. "
        "content must contain exactly one Python function and no tests or prose. "
        "Use the required function signature exactly. Do not add parameters. "
        "Equivalent safe Python implementations are allowed, but observable behaviour must match the contract."
    )
    teach = ""
    if issue["teach"]:
        teach = "\nCURRENT MAINTAINER CONVENTION:\n" + issue["rule"] + "\n"
    contract_block = ""
    if contract is not None:
        contract_block = compact_contract_text(issue, contract) + "\n"
    user = (
        f"WORKSPACE: {issue['scope']}\nFAMILY: {issue['family']}\n"
        f"REQUIRED SIGNATURE: {issue['required_signature']}\n"
        + teach
        + "CURRENT BRIEF JSON:\n"
        + issue["brief_json"]
        + "\n"
        + ("ADAPTATION MEMORY:\n" + memory + "\n" if memory else "")
        + contract_block
        + "Implement the required function now. Bound values must be embedded or ordered exactly as specified; "
        "they must not become extra function parameters."
    )
    return system, user


def efficient_bound_prompt_for(issue: Dict[str, Any], contract: Dict[str, Any]) -> Tuple[str, str]:
    """Exact executable transport prompt after verified binding."""
    system = (
        'Return only one JSON object with one string field named "content". '
        "The content string must decode to exactly one Python function. "
        "Copy the provided verified function exactly: no simplification, rewriting, omitted "
        "branches, merged statements, helpers, or extra parameters."
    )
    user = executable_contract_text(issue, contract) + "\nReturn the JSON object now."
    return system, user


def prompt_for(issue: Dict[str, Any], memory: str, contract: Optional[Dict[str, Any]]) -> Tuple[str, str, Dict[str, Any]]:
    legacy_system, legacy_user = legacy_prompt_for(issue, memory, contract)
    if contract is None:
        return legacy_system, legacy_user, {
            "prompt_mode": "legacy_unbound",
            "prompt_version": LEGACY_PROMPT_VERSION,
            "raw_memory_in_model_prompt": bool(memory),
            "legacy_prompt_tokens_approx": token_count_approx(legacy_system + "\n" + legacy_user),
            "efficient_prompt_tokens_approx": token_count_approx(legacy_system + "\n" + legacy_user),
            "static_savings_tokens_approx": 0,
        }
    system, user = efficient_bound_prompt_for(issue, contract)
    legacy_tokens = token_count_approx(legacy_system + "\n" + legacy_user)
    efficient_tokens = token_count_approx(system + "\n" + user)
    return system, user, {
        "prompt_mode": "executable_verified_contract",
        "prompt_version": PROMPT_VERSION,
        "raw_memory_in_model_prompt": False,
        "legacy_prompt_tokens_approx": legacy_tokens,
        "efficient_prompt_tokens_approx": efficient_tokens,
        "static_savings_tokens_approx": legacy_tokens - efficient_tokens,
    }


class MockModel:
    """Pipeline oracle: only a bound verified contract unlocks the expected implementation."""

    def __init__(self):
        self.calls = 0

    def count(self, text: str) -> int:
        return token_count_approx(text)

    def __call__(self, _system: str, user: str, _schema: str, issue: Dict[str, Any]) -> Dict[str, Any]:
        self.calls += 1
        has_contract = ("VERIFIED EXACT EXECUTABLE CONTRACT" in user or "VERIFIED EXECUTABLE CONTRACT" in user or "VERIFIED BOUND EXECUTION CONTRACT" in user)
        content = issue["expected_code"] if has_contract else (
            f"def {EXPECTED_NAMES[issue['family']]}(*args):\n    return None\n"
        )
        return {
            "content": content,
            "prompt_tokens": token_count_approx(user),
            "generated_tokens": token_count_approx(content),
            "strict_json": True,
            "usable": True,
            "attempts": 1,
            "raw_outputs": [json.dumps({"content": content})],
        }


class HFModel:
    def __init__(self, model_name: str):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

        self.torch = torch
        assert torch.cuda.is_available(), "CUDA GPU required for real mode"
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        quant = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=dtype,
        )
        self.tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True, local_files_only=True)
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token_id = self.tokenizer.eos_token_id
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name,
            device_map="auto",
            quantization_config=quant,
            torch_dtype=dtype,
            local_files_only=True,
        )
        self.model.eval()
        for sampling_name in ("temperature", "top_p", "top_k"):
            if hasattr(self.model.generation_config, sampling_name):
                setattr(self.model.generation_config, sampling_name, None)

    def count(self, text: str) -> int:
        return len(self.tokenizer.encode(text or "", add_special_tokens=False))

    def _chat_prompt(self, messages: List[Dict[str, str]]) -> str:
        try:
            return self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
                enable_thinking=False,
            )
        except TypeError:
            return self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )

    def _parse(self, raw: str) -> Tuple[Optional[Dict[str, Any]], bool]:
        text = raw.strip()
        try:
            obj = json.loads(text)
            return (obj if isinstance(obj, dict) and isinstance(obj.get("content"), str) else None), True
        except Exception:
            pass
        decoder = json.JSONDecoder()
        for match in re.finditer(r"\{", text):
            try:
                obj, _ = decoder.raw_decode(text[match.start():])
                if isinstance(obj, dict) and isinstance(obj.get("content"), str):
                    return obj, False
            except Exception:
                continue
        lines = text.splitlines()
        for start in range(len(lines)):
            if not lines[start].lstrip().startswith("def "):
                continue
            for end in range(len(lines), start, -1):
                candidate = "\n".join(lines[start:end]).strip()
                try:
                    tree = ast.parse(candidate)
                    if len(tree.body) == 1 and isinstance(tree.body[0], ast.FunctionDef):
                        return {"content": candidate}, False
                except Exception:
                    continue
        return None, False

    def __call__(self, system: str, user: str, _schema: str, issue: Dict[str, Any]) -> Dict[str, Any]:
        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        attempts = 0
        total_prompt = 0
        total_generated = 0
        raw_outputs: List[str] = []
        strict_first = False
        for retry in range(2):
            prompt = self._chat_prompt(messages)
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
            attempts += 1
            total_prompt += int(inputs["input_ids"].shape[-1])
            with self.torch.inference_mode():
                output = self.model.generate(
                    **inputs,
                    max_new_tokens=460,
                    do_sample=False,
                    pad_token_id=self.tokenizer.pad_token_id,
                    eos_token_id=self.tokenizer.eos_token_id,
                )
            generated = output[0, inputs["input_ids"].shape[-1]:]
            total_generated += int(generated.shape[-1])
            raw = self.tokenizer.decode(generated, skip_special_tokens=True)
            raw_outputs.append(raw)
            obj, strict = self._parse(raw)
            if retry == 0:
                strict_first = strict
            if obj is not None:
                return {
                    "content": obj["content"],
                    "prompt_tokens": total_prompt,
                    "generated_tokens": total_generated,
                    "strict_json": strict_first,
                    "usable": True,
                    "attempts": attempts,
                    "raw_outputs": raw_outputs,
                }
            messages[-1]["content"] = (
                user
                + "\nYour prior answer was invalid. Return only one JSON object with one string field: "
                + '{"content": "def required_name(...):\\n    ..."}'
            )
        return {
            "content": "",
            "prompt_tokens": total_prompt,
            "generated_tokens": total_generated,
            "strict_json": strict_first,
            "usable": False,
            "attempts": attempts,
            "raw_outputs": raw_outputs,
        }


def generate_and_score(
    model: Any,
    issue: Dict[str, Any],
    contract: Optional[Dict[str, Any]],
    system_prompt: str,
    user_prompt: str,
) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    """Generate once; allow one generic semantic repair only for verified bound contracts."""
    first = model(system_prompt, user_prompt, "content", issue)
    first_score = score_code(issue, first.get("content", ""))
    audit: Dict[str, Any] = {
        "repair_version": REPAIR_VERSION,
        "semantic_repair_used": False,
        "semantic_repair_passed": False,
        "initial_reason": first_score["reason"],
        "initial_normalized_candidate": first_score["normalized_candidate"],
        "repair_reason": None,
        "repair_normalized_candidate": None,
    }
    if first_score["passed"] or contract is None or MAX_BOUND_SEMANTIC_REPAIRS <= 0:
        return first, first_score, audit

    repair_system, repair_user = exact_copy_repair_prompts(
        issue, contract, first_score["reason"]
    )
    repaired = model(repair_system, repair_user, "content", issue)
    repaired_score = score_code(issue, repaired.get("content", ""))
    audit.update({
        "semantic_repair_used": True,
        "semantic_repair_passed": bool(repaired_score["passed"]),
        "repair_reason": repaired_score["reason"],
        "repair_normalized_candidate": repaired_score["normalized_candidate"],
    })
    merged = {
        "content": repaired.get("content", ""),
        "prompt_tokens": int(first.get("prompt_tokens", 0)) + int(repaired.get("prompt_tokens", 0)),
        "generated_tokens": int(first.get("generated_tokens", 0)) + int(repaired.get("generated_tokens", 0)),
        "strict_json": bool(first.get("strict_json", False)),
        "usable": bool(repaired.get("usable", False)),
        "attempts": int(first.get("attempts", 0)) + int(repaired.get("attempts", 0)),
        "raw_outputs": list(first.get("raw_outputs", [])) + list(repaired.get("raw_outputs", [])),
    }
    return merged, repaired_score, audit


def run_arm(
    env: Dict[str, Any],
    arm: str,
    model: Any,
    budget_icl: int,
    budget_akili: int,
) -> Dict[str, Any]:
    count_fn = getattr(model, "count", token_count_approx)
    if arm == "stateless":
        system_obj: Any = Stateless(count_fn)
    elif arm == "bounded_icl":
        system_obj = BoundedICL(budget_icl, count_fn)
    elif arm == "template_only":
        system_obj = TemplateOnly()
    elif arm == "akili":
        system_obj = AkiliCore(
            budget_akili,
            count_fn,
            derive_v4ma,
            min_evidence=2,
            max_profiles=8,
            max_versions=64,
            recent_window=10,
            max_stats_keys=96,
            max_retrieval_log=512,
        )
    else:
        raise KeyError(arm)

    evidence_counts: Dict[Tuple[str, str, int], int] = defaultdict(int)
    traces: List[Dict[str, Any]] = []
    for issue in env["issues"]:
        if hasattr(system_obj, "switch_entity"):
            system_obj.switch_entity(issue["scope"])
        memory = ""
        provenance = "NO_MEMORY"
        details: Dict[str, Any] = {}
        if arm == "bounded_icl":
            memory = system_obj.memory_prompt()
            provenance = "RAW_HISTORY"
        elif arm == "template_only" and issue["teach"]:
            memory = current_template_memory(issue["family"])
            provenance = "CURRENT_INSTRUCTION_TEMPLATE"
            details = {"current_instruction_template_retrieved": True}
        elif arm == "akili":
            if issue["teach"]:
                memory = current_template_memory(issue["family"])
                provenance = "CURRENT_INSTRUCTION_TEMPLATE"
                details = {"current_instruction_template_retrieved": True}
            else:
                memory, details = system_obj.retrieval_context(issue["family"], issue["shape"])
                provenance = details.get("primary_memory_class", "NO_MEMORY")

        memory, memory_tokens = truncate_to_budget(
            memory,
            budget_akili if arm in {"akili", "template_only"} else budget_icl,
            count_fn,
        )
        binder_applied = provenance in {
            "CURRENT_INSTRUCTION_TEMPLATE",
            "PERSISTENT_SCHEMA_TEMPLATE",
        }
        contract = bound_contract(issue) if binder_applied else None
        system_prompt, user_prompt, prompt_audit = prompt_for(issue, memory, contract)
        response, score, repair_audit = generate_and_score(
            model, issue, contract, system_prompt, user_prompt
        )
        passed = bool(score["passed"])

        if arm == "bounded_icl":
            system_obj.observe_episode(
                summary=(
                    user_prompt
                    + "\nASSISTANT OUTPUT:\n"
                    + response.get("content", "")
                    + f"\nVERIFIER: {'PASS' if passed else 'FAIL'}"
                ),
                features={},
                entity_hint=issue["scope"],
                outcome="PASS" if passed else "FAIL",
            )
        elif arm == "akili":
            key = (issue["scope"], issue["family"], issue["version"])
            if issue["teach"]:
                evidence_counts[key] += 1
            system_obj.observe_episode(
                summary=f"{issue['family']} v{issue['version']}",
                features={
                    "teach": issue["teach"],
                    "family": issue["family"],
                    "version": issue["version"],
                    "rule": issue["rule"],
                    "evidence_count": evidence_counts[key],
                    f"latest_{issue['family']}_version": issue["version"],
                },
                entity_hint=issue["scope"],
                outcome="PASS" if passed else "FAIL",
            )

        active_label = None
        if arm == "akili" and not issue["teach"]:
            active = system_obj.active_record(issue["family"])
            active_label = (active or {}).get("decision_label")
        obsolete_memory = bool(
            arm == "akili" and not issue["teach"] and active_label != f"v{issue['version']}"
        )
        trace = {
            "issue_id": issue["id"],
            "seed": issue["seed"],
            "arm": arm,
            "scope": issue["scope"],
            "family": issue["family"],
            "version": issue["version"],
            "teach": issue["teach"],
            "slice": issue["slice"],
            "required_signature": issue["required_signature"],
            "passed": passed,
            "reason": score["reason"],
            "memory_provenance": provenance,
            "memory_tokens": memory_tokens,
            "binder_applied": binder_applied,
            "contract_hash": contract.get("contract_hash") if contract else None,
            "execution_contract": contract,
            "prompt_mode": prompt_audit["prompt_mode"],
            "prompt_version": prompt_audit["prompt_version"],
            "raw_memory_in_model_prompt": prompt_audit["raw_memory_in_model_prompt"],
            "legacy_prompt_tokens_approx": prompt_audit["legacy_prompt_tokens_approx"],
            "efficient_prompt_tokens_approx": prompt_audit["efficient_prompt_tokens_approx"],
            "static_savings_tokens_approx": prompt_audit["static_savings_tokens_approx"],
            "prompt_tokens": response.get("prompt_tokens", 0),
            "generated_tokens": response.get("generated_tokens", 0),
            "usable": response.get("usable", False),
            "strict_json": response.get("strict_json", False),
            "attempts": response.get("attempts", 0),
            "raw_outputs": response.get("raw_outputs", []),
            "repair_version": repair_audit["repair_version"],
            "semantic_repair_used": repair_audit["semantic_repair_used"],
            "semantic_repair_passed": repair_audit["semantic_repair_passed"],
            "initial_reason": repair_audit["initial_reason"],
            "initial_normalized_candidate": repair_audit["initial_normalized_candidate"],
            "repair_reason": repair_audit["repair_reason"],
            "repair_normalized_candidate": repair_audit["repair_normalized_candidate"],
            "normalized_candidate": score["normalized_candidate"],
            "ast_validation": score["ast_validation"],
            "execution_result": score["execution_result"],
            "cross_scope_retrievals": getattr(system_obj, "cross_scope_retrievals", 0),
            "details": details,
            "active_decision_label": active_label,
            "obsolete_memory": obsolete_memory,
        }
        traces.append(trace)
    return {"arm": arm, "traces": traces, "system_report": system_obj.report()}


def aggregate(run_data: Dict[int, Dict[str, Any]]) -> Dict[str, Any]:
    result: Dict[str, Any] = {"arms": {}, "integrity": {}, "performance": {}}
    for arm in ARMS:
        traces = [trace for seed_data in run_data.values() for trace in seed_data[arm]["traces"]]
        passed = sum(trace["passed"] for trace in traces)
        by_slice: Dict[str, Dict[str, Any]] = {}
        for slice_name in sorted({trace["slice"] for trace in traces}):
            rows = [trace for trace in traces if trace["slice"] == slice_name]
            by_slice[slice_name] = {
                "issues": len(rows),
                "passed": sum(row["passed"] for row in rows),
                "rate": sum(row["passed"] for row in rows) / len(rows),
            }
        by_family: Dict[str, Dict[str, Any]] = {}
        for family in FAMILIES:
            rows = [trace for trace in traces if trace["family"] == family]
            by_family[family] = {
                "issues": len(rows),
                "passed": sum(row["passed"] for row in rows),
                "rate": sum(row["passed"] for row in rows) / len(rows),
            }
        result["arms"][arm] = {
            "issues": len(traces),
            "passed": passed,
            "accuracy": passed / len(traces),
            "prompt_tokens": sum(trace["prompt_tokens"] for trace in traces),
            "generated_tokens": sum(trace["generated_tokens"] for trace in traces),
            "memory_tokens": sum(trace["memory_tokens"] for trace in traces),
            "retries": sum(max(0, trace["attempts"] - 1) for trace in traces),
            "usable_rate": sum(trace["usable"] for trace in traces) / len(traces),
            "strict_first_rate": sum(trace["strict_json"] for trace in traces) / len(traces),
            "obsolete_retrievals": sum(trace["obsolete_memory"] for trace in traces),
            "binder_coverage": sum(trace["binder_applied"] for trace in traces) / len(traces),
            "semantic_repairs": sum(trace["semantic_repair_used"] for trace in traces),
            "semantic_repair_successes": sum(trace["semantic_repair_passed"] for trace in traces),
            "first_semantic_pass_rate": sum(not trace["semantic_repair_used"] for trace in traces) / len(traces),
            "by_slice": by_slice,
            "by_family": by_family,
        }

    all_traces = [
        trace
        for seed_data in run_data.values()
        for arm in ARMS
        for trace in seed_data[arm]["traces"]
    ]
    integrity = {
        "fresh_three_seed_locked_design": sorted(run_data) in ([25, 26, 27], [28, 29, 30]),
        "all_arm_issue_counts_equal": len(
            {len(run_data[seed][arm]["traces"]) for seed in run_data for arm in ARMS}
        ) == 1,
        "environment_hashes_present": all(
            seed_data.get("environment_hash") for seed_data in run_data.values()
        ),
        "required_signatures_public": all(bool(trace["required_signature"]) for trace in all_traces),
        "cross_scope_retrieval_zero": all(
            trace["cross_scope_retrievals"] == 0 for trace in all_traces
        ),
        "obsolete_retrieval_zero": all(
            not trace["obsolete_memory"] for trace in all_traces if trace["arm"] == "akili"
        ),
        "akili_teaching_template_coverage": all(
            trace["memory_provenance"] == "CURRENT_INSTRUCTION_TEMPLATE"
            for trace in all_traces
            if trace["arm"] == "akili" and trace["teach"]
        ),
        "akili_recall_uses_persistent_template": all(
            trace["memory_provenance"] == "PERSISTENT_SCHEMA_TEMPLATE"
            for trace in all_traces
            if trace["arm"] == "akili" and not trace["teach"]
        ),
        "binder_only_with_verified_template": all(
            trace["binder_applied"]
            == (
                trace["memory_provenance"]
                in {"CURRENT_INSTRUCTION_TEMPLATE", "PERSISTENT_SCHEMA_TEMPLATE"}
            )
            for trace in all_traces
        ),
        "akili_binder_full_coverage": all(
            trace["binder_applied"] for trace in all_traces if trace["arm"] == "akili"
        ),
        "template_only_no_recall_binder": all(
            not trace["binder_applied"]
            for trace in all_traces
            if trace["arm"] == "template_only" and not trace["teach"]
        ),
        "executable_prompt_only_with_verified_binding": all(
            (trace["prompt_mode"] == "executable_verified_contract")
            == trace["binder_applied"]
            for trace in all_traces
        ),
        "bound_prompt_omits_raw_memory": all(
            not trace["raw_memory_in_model_prompt"]
            for trace in all_traces
            if trace["binder_applied"]
        ),
        "unbound_arms_keep_legacy_prompt": all(
            trace["prompt_mode"] == "legacy_unbound"
            and trace["static_savings_tokens_approx"] == 0
            for trace in all_traces
            if not trace["binder_applied"]
        ),
        "akili_static_savings_at_least_30_each": all(
            trace["static_savings_tokens_approx"] >= 30
            for trace in all_traces
            if trace["arm"] == "akili"
        ),
        "raw_outputs_logged": all(isinstance(trace["raw_outputs"], list) for trace in all_traces),
        "normalized_candidates_logged": all(
            isinstance(trace["normalized_candidate"], str) for trace in all_traces
        ),
        "semantic_repair_only_with_verified_binding": all(
            (not trace["semantic_repair_used"]) or trace["binder_applied"]
            for trace in all_traces
        ),
        "semantic_repair_audits_logged": all(
            trace.get("repair_version") == REPAIR_VERSION
            and isinstance(trace.get("semantic_repair_used"), bool)
            and isinstance(trace.get("semantic_repair_passed"), bool)
            for trace in all_traces
        ),
        "semantic_repair_max_one": all(
            (not trace["semantic_repair_used"]) or trace["attempts"] <= 4
            for trace in all_traces
        ),
        "ast_and_execution_audits_logged": all(
            isinstance(trace["ast_validation"], dict)
            and isinstance(trace["execution_result"], dict)
            for trace in all_traces
        ),
        "all_system_audits_valid": all(
            run_data[seed][arm]["system_report"].get("audit_valid", True)
            for seed in run_data
            for arm in ARMS
        ),
        "all_system_states_bounded": all(
            run_data[seed][arm]["system_report"].get("state_bounded", True)
            for seed in run_data
            for arm in ARMS
        ),
    }
    result["integrity"] = integrity
    akili = result["arms"]["akili"]
    icl = result["arms"]["bounded_icl"]
    template = result["arms"]["template_only"]
    prompt_reduction = 1 - akili["prompt_tokens"] / max(icl["prompt_tokens"], 1)
    restoration_slices = ["return_after_interruption", "post_supersession_return"]
    akili_restoration = statistics.fmean(
        [akili["by_slice"][name]["rate"] for name in restoration_slices]
    )
    template_restoration = statistics.fmean(
        [template["by_slice"][name]["rate"] for name in restoration_slices]
    )
    criteria = {
        "akili_accuracy_at_least_90": akili["accuracy"] >= 0.90,
        "akili_acquisition_at_least_90": statistics.fmean(
            [akili["by_slice"][name]["rate"] for name in ("acquisition_1", "acquisition_2")]
        ) >= 0.90,
        "akili_return_at_least_90": akili["by_slice"]["return_after_interruption"]["rate"] >= 0.90,
        "akili_post_supersession_at_least_90": akili["by_slice"]["post_supersession_return"]["rate"] >= 0.90,
        "akili_restoration_advantage_at_least_30pp": akili_restoration - template_restoration >= 0.30,
        "prompt_reduction_at_least_70": prompt_reduction >= 0.70,
        "obsolete_retrieval_zero": akili["obsolete_retrievals"] == 0,
        "cross_scope_retrieval_zero": integrity["cross_scope_retrieval_zero"],
        "all_integrity_pass": all(integrity.values()),
    }
    akili_traces = [
        trace for seed_data in run_data.values() for trace in seed_data["akili"]["traces"]
    ]
    static_savings = [trace["static_savings_tokens_approx"] for trace in akili_traces]
    result["performance"] = {
        "criteria": criteria,
        "prompt_reduction": prompt_reduction,
        "akili_restoration_rate": akili_restoration,
        "template_only_restoration_rate": template_restoration,
        "restoration_advantage": akili_restoration - template_restoration,
        "prompt_representation": {
            "version": PROMPT_VERSION,
            "legacy_version": LEGACY_PROMPT_VERSION,
            "static_total_savings_tokens_approx": sum(static_savings),
            "static_mean_savings_tokens_per_issue_approx": statistics.fmean(static_savings),
            "static_min_savings_tokens_per_issue_approx": min(static_savings),
            "raw_memory_omitted_after_verified_binding": True,
            "executable_function_in_prompt": True,
        },
        "PASS": all(criteria.values()),
    }
    return result


def verifier_self_test() -> Dict[str, Any]:
    cases: List[Dict[str, Any]] = []

    def add(name: str, issue: Dict[str, Any], code: str, expected: bool) -> None:
        result = score_code(issue, code)
        cases.append(
            {
                "name": name,
                "expected": expected,
                "passed": result["passed"],
                "reason": result["reason"],
                "ok": result["passed"] is expected,
            }
        )

    env = make_env(19)
    by_family = {issue["family"]: issue for issue in env["issues"] if issue["version"] == 1}
    config = by_family["config_precedence"]
    order = config["params"]["order"]
    add(
        "safe-next-generator-accepted",
        config,
        "def resolve_config(cli, env, file_value, default):\n"
        f"    return next((value for value in ({', '.join(order)}) if value is not None), None)\n",
        True,
    )
    validation = by_family["validation_exception"]
    p = validation["params"]
    add(
        "exception-alias-accepted",
        validation,
        "def validate_value(value):\n"
        f"    exception_type = {p['exception']}\n"
        f"    if value < {p['low']!r} or value > {p['high']!r}:\n"
        f"        raise exception_type({p['message']!r})\n"
        "    return value\n",
        True,
    )
    artifact = by_family["artifact_naming"]
    add("artifact-exact-interface-accepted", artifact, artifact["expected_code"], True)
    add(
        "artifact-extra-brief-arg-rejected",
        artifact,
        "def artifact_path(root, project, artifact_name, brief):\n    return ''\n",
        False,
    )
    add(
        "unsafe-import-rejected",
        artifact,
        "def artifact_path(root, project, artifact_name):\n"
        "    import os\n"
        "    return os.path.join(root, project, artifact_name)\n",
        False,
    )

    # Regression: exact real-model canary failure shape. The outer JSON is valid,
    # but the content contains a second escaped layout layer.
    escaped_validation = (
        "def validate_value(value):\\n"
        "    if value < -4 or value > 9:\\n"
        "        raise RuntimeError('canary-range')\\n"
        "    return value"
    )
    escaped_artifact = (
        "def artifact_path(root, project, artifact_name):\\n"
        "    return f\"{root}/{project}/snapshot_{artifact_name}.bin\""
    )
    repaired_validation = normalize_content(escaped_validation)
    repaired_artifact = normalize_content(escaped_artifact)
    cases.extend([
        {
            "name": "double-escaped-layout-validation-repaired",
            "expected": True,
            "passed": score_code(make_real_canary_issues()[0], escaped_validation)["passed"],
            "reason": score_code(make_real_canary_issues()[0], escaped_validation)["reason"],
            "ok": score_code(make_real_canary_issues()[0], escaped_validation)["passed"] is True,
        },
        {
            "name": "double-escaped-layout-artifact-repaired",
            "expected": True,
            "passed": score_code(make_real_canary_issues()[-1], escaped_artifact)["passed"],
            "reason": score_code(make_real_canary_issues()[-1], escaped_artifact)["reason"],
            "ok": score_code(make_real_canary_issues()[-1], escaped_artifact)["passed"] is True,
        },
        {
            "name": "literal-newline-string-preserved",
            "expected": True,
            "passed": normalize_content('def f():\n    return "\\\\n"') == 'def f():\n    return "\\\\n"',
            "reason": "literal string escape must remain untouched",
            "ok": normalize_content('def f():\n    return "\\\\n"') == 'def f():\n    return "\\\\n"',
        },
        {
            "name": "repaired-layout-contains-real-newlines",
            "expected": True,
            "passed": "\\n" not in repaired_validation and "\n" in repaired_validation and "\n" in repaired_artifact,
            "reason": "extra layout escape layer removed",
            "ok": "\\n" not in repaired_validation and "\n" in repaired_validation and "\n" in repaired_artifact,
        },
    ])
    contracts = [bound_contract(issue) for issue in env["issues"]]
    binder_checks = {
        "all_contracts_have_hash": all(contract.get("contract_hash") for contract in contracts),
        "no_symbolic_placeholders": all("<" not in json.dumps(contract) for contract in contracts),
        "artifact_parameter_unambiguous": any(
            contract["family"] == "artifact_naming"
            and contract["exact_positional_parameters"] == ["root", "project", "artifact_name"]
            for contract in contracts
        ),
    }
    prompt_checks_rows = []
    for issue in env["issues"]:
        memory = current_template_memory(issue["family"])
        contract = bound_contract(issue)
        system, user, audit = prompt_for(issue, memory, contract)
        prompt_checks_rows.append({
            "issue_id": issue["id"],
            "family": issue["family"],
            "savings": audit["static_savings_tokens_approx"],
            "contains_signature": issue["required_signature"] in user,
            "contains_exact_executable_code": issue["expected_code"].strip() in user,
            "contains_raw_memory_header": "ADAPTATION MEMORY" in user,
            "contains_brief_header": "CURRENT BRIEF JSON" in user,
            "contains_rule_header": "CURRENT MAINTAINER CONVENTION" in user,
            "contains_placeholders": bool(re.search(r"<[A-Z][A-Z0-9_]*>", user)),
            "prompt_mode": audit["prompt_mode"],
        })
    sample_issue = env["issues"][0]
    legacy_no_contract = legacy_prompt_for(sample_issue, "", None)
    selected_no_contract = prompt_for(sample_issue, "", None)
    prompt_checks = {
        "all_bound_prompts_executable": all(row["prompt_mode"] == "executable_verified_contract" for row in prompt_checks_rows),
        "all_bound_prompts_contain_signature": all(row["contains_signature"] for row in prompt_checks_rows),
        "all_bound_prompts_contain_exact_executable_code": all(row["contains_exact_executable_code"] for row in prompt_checks_rows),
        "all_bound_prompts_omit_raw_memory": all(not row["contains_raw_memory_header"] for row in prompt_checks_rows),
        "all_bound_prompts_omit_brief": all(not row["contains_brief_header"] for row in prompt_checks_rows),
        "all_bound_prompts_omit_rule_copy": all(not row["contains_rule_header"] for row in prompt_checks_rows),
        "all_bound_prompts_have_no_symbolic_slots": all(not row["contains_placeholders"] for row in prompt_checks_rows),
        "minimum_static_savings_at_least_30": min(row["savings"] for row in prompt_checks_rows) >= 30,
        "mean_static_savings": statistics.fmean(row["savings"] for row in prompt_checks_rows),
        "minimum_static_savings": min(row["savings"] for row in prompt_checks_rows),
        "unbound_prompt_byte_equivalent": selected_no_contract[:2] == legacy_no_contract,
    }
    class OmitBatchThenCopyModel:
        def __init__(self):
            self.calls = 0

        def count(self, value: str) -> int:
            return token_count_approx(value)

        def __call__(self, _system: str, _user: str, _schema: str, issue: Dict[str, Any]) -> Dict[str, Any]:
            self.calls += 1
            if self.calls == 1:
                content = (
                    "def make_batches(items):\n"
                    "    return [items[i:i+3] for i in range(0, len(items), 3)]\n"
                )
            else:
                content = issue["expected_code"]
            return {
                "content": content,
                "prompt_tokens": token_count_approx(_user),
                "generated_tokens": token_count_approx(content),
                "strict_json": True,
                "usable": True,
                "attempts": 1,
                "raw_outputs": [json.dumps({"content": content})],
            }

    batch_issue = next(
        row for row in make_real_canary_issues() if row["family"] == "batch_tail_policy"
    )
    batch_contract = bound_contract(batch_issue)
    batch_system, batch_user, _ = prompt_for(
        batch_issue, current_template_memory("batch_tail_policy"), batch_contract
    )
    repaired_response, repaired_score, repaired_audit = generate_and_score(
        OmitBatchThenCopyModel(), batch_issue, batch_contract, batch_system, batch_user
    )
    cases.extend([
        {
            "name": "batch-tail-omission-detected-before-repair",
            "ok": repaired_audit["initial_reason"].startswith("batch mismatch"),
            "passed": repaired_audit["initial_reason"].startswith("batch mismatch"),
        },
        {
            "name": "batch-tail-omission-repaired-by-exact-copy",
            "ok": repaired_audit["semantic_repair_used"] and repaired_audit["semantic_repair_passed"] and repaired_score["passed"],
            "passed": repaired_audit["semantic_repair_used"] and repaired_audit["semantic_repair_passed"] and repaired_score["passed"],
        },
        {
            "name": "batch-tail-repair-counts-both-generations",
            "ok": repaired_response["attempts"] == 2 and len(repaired_response["raw_outputs"]) == 2,
            "passed": repaired_response["attempts"] == 2 and len(repaired_response["raw_outputs"]) == 2,
        },
        {
            "name": "exact-transport-prompt-forbids-simplification",
            "ok": "Do not simplify" in batch_user and "safe equivalent" not in batch_user.lower(),
            "passed": "Do not simplify" in batch_user and "safe equivalent" not in batch_user.lower(),
        },
    ])

    return {
        "protocol": PROTOCOL,
        "verifier_version": VERIFIER_VERSION,
        "binder_version": BINDER_VERSION,
        "normalizer_version": NORMALIZER_VERSION,
        "repair_version": REPAIR_VERSION,
        "max_bound_semantic_repairs": MAX_BOUND_SEMANTIC_REPAIRS,
        "cases": cases,
        "binder_checks": binder_checks,
        "prompt_checks": prompt_checks,
        "PASS": (
            all(case["ok"] for case in cases)
            and all(binder_checks.values())
            and all(value for key, value in prompt_checks.items() if isinstance(value, bool))
        ),
    }



def make_real_canary_issues() -> List[Dict[str, Any]]:
    """Six engineering-only issues. They are never included in benchmark metrics."""
    params_by_family: Dict[str, Dict[str, Any]] = {
        "validation_exception": {
            "low": -4, "high": 9, "exception": "RuntimeError", "message": "canary-range",
        },
        "serialization_mapping": {
            "in1": "alpha_id", "in2": "beta_kind", "out1": "object_id", "out2": "object_type",
        },
        "structured_logging": {
            "level": "NOTICE", "prefix": "canary:", "source": "service-canary",
        },
        "config_precedence": {
            "order": ["file_value", "cli", "env", "default"],
        },
        "batch_tail_policy": {
            "size": 3, "drop": True,
        },
        "artifact_naming": {
            "prefix": "snapshot", "ext": "bin",
        },
    }
    issues: List[Dict[str, Any]] = []
    for index, family in enumerate(FAMILIES, start=1):
        params = params_by_family[family]
        issue: Dict[str, Any] = {
            "id": 90_000 + index,
            "seed": "engineering-canary",
            "scope": f"canary-{index}",
            "family": family,
            "shape": operation_shape(family),
            "version": 99,
            "teach": True,
            "slice": "real_model_canary",
            "params": params,
            "required_signature": REQUIRED_SIGNATURES[family],
            "rule": public_rule({"family": family, "params": params}),
        }
        issue["expected_code"] = expected_code(issue)
        issue["brief_json"] = json.dumps({
            "scope": issue["scope"],
            "family": family,
            "version": 99,
            "required_signature": REQUIRED_SIGNATURES[family],
            "parameters": params,
        }, sort_keys=True)
        issues.append(issue)
    return issues


def run_real_model_canary(model: Any, model_id: str) -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    for issue in make_real_canary_issues():
        contract = bound_contract(issue)
        system_prompt, user_prompt, prompt_audit = prompt_for(
            issue, current_template_memory(issue["family"]), contract
        )
        response, score, repair_audit = generate_and_score(
            model, issue, contract, system_prompt, user_prompt
        )
        rows.append({
            "family": issue["family"],
            "passed": bool(score["passed"]),
            "reason": score["reason"],
            "required_signature": issue["required_signature"],
            "contract_hash": contract["contract_hash"],
            "prompt_mode": prompt_audit["prompt_mode"],
            "prompt_tokens": response.get("prompt_tokens", 0),
            "generated_tokens": response.get("generated_tokens", 0),
            "raw_outputs": response.get("raw_outputs", []),
            "repair_version": repair_audit["repair_version"],
            "semantic_repair_used": repair_audit["semantic_repair_used"],
            "semantic_repair_passed": repair_audit["semantic_repair_passed"],
            "initial_reason": repair_audit["initial_reason"],
            "initial_normalized_candidate": repair_audit["initial_normalized_candidate"],
            "repair_reason": repair_audit["repair_reason"],
            "repair_normalized_candidate": repair_audit["repair_normalized_candidate"],
            "normalized_candidate": score["normalized_candidate"],
            "ast_validation": score["ast_validation"],
            "execution_result": score["execution_result"],
        })
    return {
        "version": CANARY_VERSION,
        "model_id": model_id,
        "issues": len(rows),
        "passed": sum(row["passed"] for row in rows),
        "first_passed": sum(not row["semantic_repair_used"] and row["passed"] for row in rows),
        "semantic_repairs": sum(row["semantic_repair_used"] for row in rows),
        "repair_successes": sum(row["semantic_repair_passed"] for row in rows),
        "PASS": all(row["passed"] for row in rows),
        "not_in_benchmark_metrics": True,
        "rows": rows,
    }

def run(
    phase: str,
    mode: str,
    output: Path,
    model_name: str,
    model_id: str,
    budget_icl: int,
    budget_akili: int,
    resume: bool,
    require_real_canary: bool,
) -> Dict[str, Any]:
    assert phase in LOCKED_PHASE_SEEDS
    seeds = LOCKED_PHASE_SEEDS[phase]
    output.mkdir(parents=True, exist_ok=True)
    model: Any = MockModel() if mode == "mock" else HFModel(model_name)
    real_model_canary: Optional[Dict[str, Any]] = None
    if mode == "real" and require_real_canary:
        print(f"REAL MODEL CANARY: {model_id}", flush=True)
        real_model_canary = run_real_model_canary(model, model_id)
        (output / "REAL_MODEL_CANARY.json").write_text(
            json.dumps(real_model_canary, indent=2), encoding="utf-8"
        )
        print(json.dumps({
            "canary_version": real_model_canary["version"],
            "model_id": model_id,
            "passed": real_model_canary["passed"],
            "first_passed": real_model_canary["first_passed"],
            "semantic_repairs": real_model_canary["semantic_repairs"],
            "repair_successes": real_model_canary["repair_successes"],
            "issues": real_model_canary["issues"],
            "PASS": real_model_canary["PASS"],
        }, indent=2))
        if not real_model_canary["PASS"]:
            failed = [row for row in real_model_canary["rows"] if not row["passed"]]
            raise RuntimeError(
                "Real-model executable-contract canary failed before benchmark: "
                + json.dumps(failed, indent=2)
            )
    run_data: Dict[int, Dict[str, Any]] = {}
    for seed in seeds:
        env = make_env(seed)
        run_data[seed] = {"environment_hash": env["environment_hash"]}
        for arm in ARMS:
            output_path = output / f"seed{seed}_{arm}.json"
            if resume and output_path.exists():
                cached = json.loads(output_path.read_text(encoding="utf-8"))
                valid_cache = (
                    cached.get("protocol") == PROTOCOL
                    and cached.get("model_id") == model_id
                    and cached.get("environment_hash") == env["environment_hash"]
                    and cached.get("arm") == arm
                    and len(cached.get("traces", [])) == len(env["issues"])
                )
                if valid_cache:
                    print(f"seed={seed} arm={arm} [resume]", flush=True)
                    run_data[seed][arm] = cached
                    continue
            print(f"seed={seed} arm={arm}", flush=True)
            arm_result = run_arm(env, arm, model, budget_icl, budget_akili)
            arm_result.update(
                {
                    "protocol": PROTOCOL,
                    "phase": phase,
                    "model_id": model_id,
                    "environment_hash": env["environment_hash"],
                }
            )
            run_data[seed][arm] = arm_result
            output_path.write_text(json.dumps(arm_result, indent=2), encoding="utf-8")
    summary = aggregate(run_data)
    receipt = {
        "protocol": PROTOCOL,
        "phase": phase,
        "mode": mode,
        "seeds": seeds,
        "model": model_name if mode == "real" else "prompt-path mock",
        "model_id": model_id,
        "budgets": {"bounded_icl": budget_icl, "akili": budget_akili},
        "binder_version": BINDER_VERSION,
        "verifier_version": VERIFIER_VERSION,
        "prompt_version": PROMPT_VERSION,
        "legacy_prompt_version": LEGACY_PROMPT_VERSION,
        "canary_version": CANARY_VERSION,
        "normalizer_version": NORMALIZER_VERSION,
        "repair_version": REPAIR_VERSION,
        "max_bound_semantic_repairs": MAX_BOUND_SEMANTIC_REPAIRS,
        "real_model_canary": real_model_canary,
        "environment_hashes": {str(seed): run_data[seed]["environment_hash"] for seed in seeds},
        "summary": summary,
        "implementation_fingerprint": canonical_hash(
            {
                "protocol": PROTOCOL,
                "families": FAMILIES,
                "templates": {family: render_template(family) for family in FAMILIES},
                "required_signatures": REQUIRED_SIGNATURES,
                "binder_version": BINDER_VERSION,
                "verifier_version": VERIFIER_VERSION,
                "prompt_version": PROMPT_VERSION,
                "legacy_prompt_version": LEGACY_PROMPT_VERSION,
                "canary_version": CANARY_VERSION,
                "repair_version": REPAIR_VERSION,
                "max_bound_semantic_repairs": MAX_BOUND_SEMANTIC_REPAIRS,
                "seeds": LOCKED_PHASE_SEEDS,
            }
        ),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    (output / "FINAL_RECEIPT.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return receipt


def parse_args(argv: Optional[Iterable[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=LOCKED_PHASE_SEEDS, default=os.getenv("AKILI_V4MAE2_PHASE", "development"))
    parser.add_argument("--mode", choices=["mock", "real"], default=os.getenv("AKILI_V4MAE2_MODE", "mock"))
    parser.add_argument("--output", type=Path, default=Path(os.getenv("AKILI_V4MAE2_OUTPUT", "./akili_v4mae2_output")))
    parser.add_argument("--model", default=os.getenv("AKILI_V4MAE2_MODEL", "Qwen/Qwen3-4B"))
    parser.add_argument("--model-id", default=os.getenv("AKILI_V4MAE2_MODEL_ID", "model"))
    parser.add_argument("--icl-budget", type=int, default=int(os.getenv("AKILI_V4MAE2_ICL_BUDGET", "1024")))
    parser.add_argument("--akili-budget", type=int, default=int(os.getenv("AKILI_V4MAE2_AKILI_BUDGET", "288")))
    parser.add_argument("--no-resume", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--require-real-canary", action="store_true")
    return parser.parse_args(argv)


if __name__ == "__main__":
    args = parse_args()
    if args.self_test:
        result = verifier_self_test()
        print(json.dumps(result, indent=2))
        raise SystemExit(0 if result["PASS"] else 3)
    receipt = run(
        phase=args.phase,
        mode=args.mode,
        output=args.output,
        model_name=args.model,
        model_id=args.model_id,
        budget_icl=args.icl_budget,
        budget_akili=args.akili_budget,
        resume=not args.no_resume,
        require_real_canary=args.require_real_canary,
    )
    raise SystemExit(0 if all(receipt["summary"]["integrity"].values()) else 2)
