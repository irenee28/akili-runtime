# Akili V4-MA-E2.2 Run Guide

## Protocol

`akili-v4ma-exact-contract-transport-v2.2`

Development seeds: `25, 26, 27`  
Held-out seeds: `28, 29, 30`

Models:

- `Qwen/Qwen3-4B`, requested revision `1cfa9a7`
- `mistralai/Mistral-Nemo-Instruct-2407`, revision `04d8a90549d23fc6bd7f642064003592df51e9b3`

## Exact contract transport scope

V4-MA-E2.2 is a new exact-contract transport protocol created after the E2.1 Mistral canary correctly detected an omitted batch-tail branch before any Mistral benchmark issue ran. The verified bound prompt now requires verbatim transport of the complete function. If the first bound candidate still fails semantic verification, one generic verifier-guided exact-copy correction is allowed. The correction is not family-specific, and all extra prompt tokens, generated tokens, attempts and raw outputs are counted.

V4-MA-E2.2 preserves the V3.1.1a lifecycle core, six families, typed binder, exact interfaces, semantic verifier, arms, budgets, model revisions and 70% efficiency threshold.

Unbound arms use the V4-MA prompt unchanged. When a current or persistent verified template enables deterministic binding, the model receives the exact bound Python function with a code hash and nonblank-line count. The prompt explicitly forbids simplification, omission, merging, reordering or rewriting. One semantic-repair attempt is available only to verified bound contracts and is fully audited. Each model must first pass six engineering-only real-model canaries; canaries are excluded from benchmark metrics.

## Run order

1. Upload and run `Akili_V4MAE22_Exact_Contract_Transport_Development_RunPod_OneClick.ipynb` in the same RunPod environment.
2. Run its single cell from a fresh kernel without edits.
3. Review `V4MAE22_DEVELOPMENT_MANIFEST.json` and both model receipts.
4. Run the frozen held-out notebook only if both models pass all development gates. The notebook enforces this.

## Output paths

Development:

`/workspace/AKILI_CL/results/akili_v4mae22_development_seeds_25_26_27`

Held-out:

`/workspace/AKILI_CL/results/akili_v4mae22_heldout_seeds_28_29_30`

## Frozen source hashes

- V3.1.1a core: `4b15893ebdb9d721d52296e369efcc3a5a94e411a58cf0210e9d5011ce0e8e98`
- V4-MA-E2.2 benchmark: `14b99a78535eb073a73faad9735a82bcdd6de0c848a31cf892db8d70fd28bd02`

The benchmark supports arm-level resume using protocol, model ID, environment hash, arm and issue-count validation.
